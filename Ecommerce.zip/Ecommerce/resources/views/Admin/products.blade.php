@extends('layouts.app')




@section('content')

	<div class="container-fluid upload-products">
	
	<div class="row">
		<div class="col-lg-2" style="margin-top: 22px;">

          @include('Admin.sidebar')
        </div>

        <div class="col-lg-10">

        	<table id="myTable" class="display">
    <thead>
        <tr>
        	<th>Sno</th>
            <th>Image</th>
            <th>Product Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Weight</th>
            <th>view</th>

        </tr>
    </thead>
    <tbody>
    	<?php $sno=1; ?>
    	@foreach($product as $product)
    	
        <tr>
        	
        	<td>{{$sno++}}</td>
            <td><img width="10%" class="img-responsive" src="{{asset('public/img/'.$product->image['name'])}}"></td>
            <td>{{$product->name}}</td>
            <td>{{$product->category->name}}</td>
            <td>{{$product->price}}</td>
            <td>{{$product->discount}}</td>
            <td>{{$product->weight}}</td>
            <td><a href="{{url('Showproduct',$product->id)}}" class="btn btn-success btn-sm">View Product</a></td>
               
        </tr>
 
        @endforeach
        
    </tbody>
</table>

        </div>


    </div>

    </div>

@endsection