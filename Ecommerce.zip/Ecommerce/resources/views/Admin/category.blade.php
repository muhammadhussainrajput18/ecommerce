@extends('layouts.app')

@section('content')


<div class="container-fluid ">
	
	<div class="container">
		
		<div class="row">
			
			<div class="col-lg-2">
				
				@include('Admin.sidebar')

			</div>

			<div class="col-lg-8">

				@if(session()->has('message'))
						<p class="alert alert-success">{{session()->get('message')}}</p>
					@endif

				<a href="{{route('categories.create')}}" class="btn-success btn btn-sm pull-right" style="margin-bottom: 40px;">Add New Category</a>

				
				<table id="myTable" class="display">
    <thead>
        <tr>
        	<th>Sno</th>
            <th>Name</th>
            
            <th>Delete</th>
            <th>View</th>

        </tr>
    </thead>
    <tbody>
    	<?php $sno=1; ?>
    	@foreach($category as $category)
    	
        <tr>
        	
        	<td>{{$sno++}}</td>
            
            <td>{{$category->name}}</td>
            
            <td><a href="#" 
            	onclick="
            	var result = confirm('Are You Sure You Want TO Delete Category');
            	if (result) {
            		event.preventDefault();
            		document.getElementById('delete-form').submit();
            	}
            	" 
             class="btn btn-danger btn-sm">Delete</a>

             <form action="{{route('categories.destroy' , [$category->id])}}" name="delete-form" id="delete-form" method="post">
             	{{csrf_field()}}

             	<input type="hidden" name="_method" value="Delete">
             </form>

         </td>
            <td><a href="" class="btn btn-success btn-sm">View  Category</a></td>
               
        </tr>
 
        @endforeach
        
    </tbody>
</table>

			</div>

		</div>

	</div>

</div>

@endsection