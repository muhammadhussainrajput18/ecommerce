@extends('layouts.app')

@section('content')


<div class="container-fluid ">
	
	<div class="row">
		<div class="col-lg-2" style="margin-top: 22px;">

          @include('Admin.sidebar')
        </div>

        <div class="col-lg-7">


        	<h2 class="text-left">Edit Product {{$product->name}} Of Category: ({{$product->category->name}})</h2>


        	<form class="col-md-10" style="margin-top: 30px;" action="{{url('updateproduct')}}" method="post">
        		{{csrf_field() }}
        		
        		
        		<h4>Product Name</h4>
        		<input type="text" name="name" value="{{$product->name}}" class="form-control">

        		<input type="hidden" name="id" value="{{$product->id}}">

        		<h4>Product Category</h4>
        		<select name="category" class="form-control">
        			<option value="{{$product->category->id}}">{{$product->category->name}}</option>
        			@foreach($category as $category)
        			<option value="{{$category->id}}">{{$category->name}}</option>
        			@endforeach
        		</select>

        		<h4>Product Description</h4>
        		<textarea style="height: 200px;" name="description" class="form-control">{{$product->description}}</textarea>

        		<h4>Product Price</h4>
        		<input type="number" name="price" value="{{$product->price}}" class="form-control">

        		

        		<h4>Product Discount <span style="font-size: 14px;">Choose Just In Percent %</span></h4>
        		<select name="discount" class="form-control">
        			@for($d=1; $d<=100 ; $d++)
        			<option value="{{$d}}">{{$d}}</option>
        			@endfor
        		</select>

        		<h4>Product Weight <span style="font-size: 14px;">Enter Weight In Grams</span></h4>
        		<input type="number" name="weight" value="{{$product->weight}}" class="form-control">

        		<input style="margin-top: 30px;" type="submit" name="submit" value="Edit Product" class="btn btn-success btn-md form-control">






        	</form>
        		


        </div>

        <div class="col-lg-2 text-left" style="margin-top: 30px;">

        	<h4 class="text-left">Update Product Image</h4>

        	@if(session()->has('message'))
						<p class="alert alert-success">{{session()->get('message')}}</p>
					@endif
        	<img width="100%" class="img-responsive" src="{{asset('public/img/'.$product->image['name'])}}">

        	<form action="{{url('updateproductimage')}}" method="post" enctype="multipart/form-data">
        		{{csrf_field() }}
        		<input type="hidden" name="id" value="{{$product->image['id']}}">
        		<input type="file" name="image" class="form-control">
        		<input type="submit" name="submit" value="Update Image" class="btn btn-success form-control">
        	</form>
        </div>

    </div>

</div>


@endsection