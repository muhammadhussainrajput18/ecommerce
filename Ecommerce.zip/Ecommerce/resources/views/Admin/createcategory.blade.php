@extends('layouts.app')

@section('content')

<div class="container-fluid upload-products">
	
	<div class="row">
		<div class="col-lg-2" style="margin-top: 22px;">

          @include('Admin.sidebar')
        </div>

        <div class="col-lg-6">
        	@if(session()->has('message'))
						<p class="alert alert-success">{{session()->get('message')}}</p>
					@endif

        	<h2>Add New Category</h2>
        	<br><br>
        	<form action="{{route('categories.store')}}"  method="post" >

        		{{csrf_field()}}
        		
        		<h4>Category Name</h4>
        		<input type="text" name="name" class="form-control">


        		<h4>Category Description</h4>
        		<textarea name="description" class="form-control" style="height: 200px"></textarea>

        		<br>

        		<input type="submit" name="submit" class="form-control btn btn-success">
        	</form>

        </div>


    </div>

</div>


@endsection