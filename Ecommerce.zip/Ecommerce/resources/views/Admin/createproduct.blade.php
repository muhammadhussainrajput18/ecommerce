@extends('layouts.app')


@section('content')


<div class="container-fluid upload-products">
	
	<div class="row">
		<div class="col-lg-offset-1 col-lg-2" style="margin-top: 22px;">

          @include('Admin.sidebar')
        </div>

        <div class="col-lg-6">

        	@if(session()->has('message'))
						<p class="alert alert-success">{{session()->get('message')}}</p>
					@endif
        	
        	<h3 class="" style="background: #3097d1; padding: 20px; color: white">Upload Products</h3>

        	<form action="{{route('products.store')}}" method="post" enctype="multipart/form-data">
        		{{csrf_field()}}

        		<h4>Product Name</h4>
        		@if($errors->get('name'))
                @foreach($errors->get('name') as $message)
                <span class="label label-danger">{{$message}}</span>
                <br>
        		@endforeach
                 @endif
                 <input type="text" name="name" placeholder="Product name" class="form-control">

        		<h4>Select Product Category</h4>
        		<select name="category" class="form-control">
        			<option value="">Select Category</option>
        			@foreach($category as $category)
        			<option value="{{$category->id}}">{{$category->name}}</option>
        			@endforeach
        		</select>

        		<h4>Product Description</h4>
        		<textarea placeholder="Product description" style="height: 200px;" name="description" class="form-control"></textarea>

        		<h4>Product Original Price</h4>
        		<input type="number" name="price" placeholder="Product Price" class="form-control">

        		<h4>Product Discount Price</h4>
        		<input type="number" name="discount" placeholder="Product Discount Price" class="form-control">

        		<h4>Product weight</h4>
        		<input type="number" name="weight" placeholder="Product Weight in grams" class="form-control">

        		

        		

        		<h4>Uplaod Product Image</h4>
        		<input type="file" name="image" class="form-control">

        		<br>


        		<input type="submit" style="background: #3097d1;" name="submit" value="Upload Product" class="btn btn-success btn-md form-control">





        	</form>

        </div>

	</div>
</div>

@endsection