<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="{{ asset('public/css/app.css') }}" rel="stylesheet">

    <link href="{{ asset('public/css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('public/css/datatable.css') }}" rel="stylesheet">
    
</head>
<body>
    <div id="app">

        <nav class="navbar navbar-default my-nav">
  <div class="container-fluid con-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand logo" href="#">MY SHOP</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      

      
      <ul class="nav navbar-nav navbar-right nav-right">



        <li><a href="#">Home</a></li>

        <li class="dropdown my-deopdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
            @if(Session::has('locale'))
            {{session('locale')}}
            @else
                {{Config::get('app.locale')}}
            @endif
            <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="{{url('language/en')}}">English</a></li>
            <li><a href="{{url('language/ur')}}">Urdu</a></li>
            
          </ul>
        </li>
        <li><a href="{{url('cart')}}">Cart 
            @if(Session::get('cart'))

            <?php
                $cart=Session::get('cart')
            ?>
            
            @if($cart->getCountProduct()>=1 )
            {{$cart->getCountProduct()}}

            @endif

            @endif


        </a></li>
        <!--Authentication Links -->
                        @guest
                            <li><a href="{{ route('login') }}">{{__('auth.login')}}</a></li>
                            <li><a href="{{ route('register') }}">{{__('auth.register')}}</a></li>
                        @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true" v-pre>
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        @endguest

<form class="navbar-form navbar-right">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
      </ul>


    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
        
        @yield('content')
    </div>

    <!-- Scripts -->
    <script src="{{ asset('public/js/app.js') }}"></script>
    
    <script src="{{ asset('public/js/datatable.js') }}"></script>

    <script type="text/javascript">
    $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>
</body>
</html>
