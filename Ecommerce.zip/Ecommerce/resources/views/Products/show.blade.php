@extends('layouts.app')

@section('content')



			

			<div class="container">
				<div class="row">
					
					@if(session()->has('message'))
						<p class="alert alert-success">{{session()->get('message')}}</p>
					@endif
					<div class="col-lg-4"></div>

					<div class="col-lg-8">
						
						<h2>{{$product->name}}</h2>
						<p>{{$product->description}}</p>

						@if($product->discount)
							<h4><strong>Original Price</strong> <del>{{$product->price}}</del></h4>

							<h4><strong>Discounted Price Is</strong> <span>{{ floor($product->price * ((100-$product->discount) / 100 )) }}</span></h4>

							<h5><strong>Off</strong>      {{$product->discount}}%</h5>

							@else
							<h4><strong>Price</strong> {{$product->price}}</h4>


						@endif

							<p>Product Catogary : {{$product->category->name}}</p>

							<a href="{{route('addToCart',$product)}}">Add Cart</a>
						

					</div>


				</div>
			</div>
		


@endsection