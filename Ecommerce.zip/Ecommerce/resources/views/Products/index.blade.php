@extends('layouts.app')
@section('content')



@include ('includes.slider')



<div class="container-fluid">
	<div class="row">
		
		<div class="col-lg-3">
			
			<h3>Catogries</h3>

			<ul>
					@foreach($categories as $category)
					<li><a href="">{{$category->name}}</a></li>
					@endforeach
				</ul>

		</div>


		<div class="col-lg-9">
			
			<div class="row">
				<h4>Recent Products</h4>


				
			</div>

			
			<div class="row">
				@foreach($product as $products)
				<div class="col-lg-3">
					<a href="{{route('products.show', [$products->id])}}">
					<img width="100%" class="img-responsive" src="{{asset('public/images/ladies/11.jpg')}}">
					<h3>{{$products->name}}</h3>
				</a>
				</div>
				@endforeach
			</div>
			
		</div>

	</div>
</div>

<!-- @foreach($product as $products)

<h3>{{$products->name}}</h3>

@endforeach
 -->

@endsection