@extends ('layouts.app')

@section('content')


<div class="container">
	<h1>Cart</h1>

	@if(isset($cart) && $cart->getContents())

	<div class="table table-responsive">
			
			<table class="table text-muted">
				<tr>
				<th>Product Image</th>
				<th>Product Name</th>
				<th>Product Quantity</th>
				<th>Product Price</th>
				<th>Action</th>
			</tr>

			@foreach($cart->getContents() as $id=>$product)
			<tr>
				<td><img src="" /></td>

				<td>{{$product['product']->name}}</td>

				<td>
					<form action="{{route('update',$product)}}" method="post">
							{{csrf_field()}}
						<input type="number"  name="qty" id="qty" class="form-control text-center" min="0" max="99" value="{{$product['qty']}}">
						<input type="submit" name="update" class="form-control btn btn-success">

					</form>
				</td>

				<td>
					<h3>{{$product['price']}}</h3>
				</td>

				<td>
					<form action="{{route('remove', $product)}}" method="post">
						{{csrf_field()}}
						<input type="submit" name="remove" value="x Remove" class="form-control btn btn-danger">

					</form>
				</td>

			</tr>


			@endforeach

			<tr>
				<td colspan="2" >Total Quantity : </td>
				<td class="text-center">{{$cart->getTotalQty()}}</td>

			</tr>

			<tr>
				<td colspan="3">Total Price : </td>
				<td class="text-center">{{$cart->getTotalPrice()}}</td>

			</tr>

			<tr>
				<td><a href="{{url('checkout')}}" class="btn btn-success btn-lg">Checkout</a></td>
			</tr>
			</table>

	</div>

	@else

		<p class="alert alert-danger">No Product in your cart</p>

	@endif

</div>

@endsection