<?php

use Faker\Generator as Faker;

$factory->define(App\Product::class, function (Faker $faker) {
    return [
        //

        'name' => $faker->title,
        'description' => $faker->paragraph(5),
        'price' => rand(1000,3000),
        'weight' =>rand(1,3000),
        'discount'=>rand(1,90),
        'category_id'=>rand(1,10),
        

    ];
});
