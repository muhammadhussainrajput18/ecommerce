<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->middleware('language'); 


Route::get('/', 'ProductController@index');
Route::resource('products', 'ProductController'); 

Route::post('updateproduct', 'ProductController@update'); 
Route::post('updateproductimage' , 'ProductController@updateimage');

Route::get('/addTocart/{product}', 'ProductController@addToCart')->name('addToCart');

Route::post('remove/{product}', 'ProductController@removeProduct')->name('remove');
Route::post('update/{product}' , 'ProductController@updateProduct')->name('update');

Route::get('/cart' , 'ProductController@Cart');

Route::resource('categories', 'CategoryController');

Route::resource('checkout', 'OrderController');




Auth::routes();
Route::get('language/{lang}', function($lang){
	\Session::put('locale', $lang);
	return redirect()->back();
})->middleware('language');
Route::get('/dashboard', 'AdminController@index')->name('home');
Route::get('Allproducts', 'ProductController@showproductstoadmin');
Route::get('Showproduct/{product}', 'ProductController@showproduct');
