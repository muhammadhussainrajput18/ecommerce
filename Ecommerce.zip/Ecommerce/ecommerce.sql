-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2020 at 07:03 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Mr.', 'Harum aut totam vel. Est pariatur ex est rerum. Id unde minus exercitationem iure assumenda velit iure. Aliquid dolores autem eligendi iure facilis. Ipsum veniam unde unde tempora eos. Quasi est eos dolore alias. Magnam adipisci qui dolore ipsa. Et autem et reprehenderit qui perferendis. Est id dolores eos dolor nihil. Optio nam molestiae et quae. Aut ab quam ut.', '2019-04-14 09:07:18', '2019-04-14 09:07:18'),
(2, 'Prof.', 'Veniam magnam praesentium amet laborum voluptas. Aut placeat nihil cum. Impedit nobis ipsa quo est enim nihil iusto. Ratione nisi explicabo odio omnis quo. Ut aliquam quos nulla officiis veniam. Possimus nulla omnis sequi asperiores pariatur aut. Consectetur quibusdam nisi ipsam dolores aut nihil. Modi nemo quibusdam nobis aut. Est necessitatibus assumenda consequatur et suscipit voluptatibus.', '2019-04-14 09:07:18', '2019-04-14 09:07:18'),
(3, 'Dr.', 'Voluptatem eveniet voluptas velit. In labore laborum ullam nostrum ut. Modi in autem quos et iusto quam. Tempora accusantium asperiores illum sit laborum vel debitis. Veniam magnam eaque omnis molestias dolores voluptatibus. Suscipit a doloribus iusto voluptatum blanditiis voluptas et. Sapiente dolores ut dolor cumque distinctio atque quidem. Fugit ut placeat ex qui explicabo voluptatem laudantium.', '2019-04-14 09:07:19', '2019-04-14 09:07:19'),
(4, 'Mrs.', 'Quam aspernatur alias quod mollitia. Harum et illum voluptatem id beatae quis praesentium. In nesciunt cum nisi. Reprehenderit qui molestias recusandae eveniet. Repellendus architecto deserunt sint et et enim. Dolores autem est magnam soluta. Porro ab perspiciatis eius est voluptatum culpa recusandae. Excepturi sed qui voluptas tempore. Est corrupti commodi sit enim sit laudantium in. Neque porro reiciendis dignissimos. Similique nulla ut aut voluptatem est. Vel vero minima omnis pariatur exercitationem. Delectus voluptatum delectus nisi est non amet ea id. Quia voluptates molestiae nobis inventore.', '2019-04-14 09:07:19', '2019-04-14 09:07:19'),
(5, 'Prof.', 'Ab deleniti voluptatum et illum. Debitis pariatur impedit hic aut nobis beatae. Dignissimos nemo molestiae assumenda in est repellat doloribus. Possimus id odit dolor vero id. Quia consectetur beatae porro ab. Est alias id nobis reiciendis culpa pariatur error amet. Debitis optio et et non animi quo. Architecto tempore cumque sit cumque dolorem aut perspiciatis. Sed et ea nobis est. Sunt quia et qui ab a est. Temporibus dolor minus ut omnis.', '2019-04-14 09:07:19', '2019-04-14 09:07:19'),
(6, 'Dr.', 'Non exercitationem quaerat velit accusantium qui sit consequatur. Voluptas debitis eum aliquam sed nihil. Maiores mollitia quaerat delectus sed. Laboriosam dolorem molestiae commodi aut. Accusamus dolor ut odit saepe asperiores voluptate. Corporis ea quibusdam nihil nostrum pariatur distinctio natus. Fugiat tenetur vel culpa eveniet.', '2019-04-14 09:07:19', '2019-04-14 09:07:19'),
(7, 'Mr.', 'Sint expedita possimus quasi voluptatem omnis exercitationem. Tenetur quam distinctio dolorem repellat blanditiis quam. Officiis totam nam cum atque. Dolorum pariatur nesciunt reprehenderit consequatur qui eos ut. Optio necessitatibus odio magni similique optio perspiciatis. Odit recusandae officiis ut assumenda porro rerum culpa incidunt. Et error voluptatibus impedit assumenda voluptatum atque. Iusto repudiandae laboriosam minus ratione. Quisquam vitae non voluptatem. Quia et et accusantium nesciunt id ea. Inventore molestiae exercitationem laudantium explicabo quisquam libero. Dolores ex sed quae necessitatibus. Sed earum deleniti iure possimus quae quasi deserunt sed.', '2019-04-14 09:07:19', '2019-04-14 09:07:19'),
(8, 'Prof.', 'Et amet ut nemo. Unde pariatur qui est molestiae ad sed et. Ipsa vel suscipit corrupti eos maiores provident delectus atque. Enim nihil voluptas ad earum suscipit. Quos quis perferendis nisi officiis magni ab. Minima ipsum dolorum reiciendis accusantium officiis. Placeat neque deleniti quos vel qui hic. Corrupti hic iste quasi ea consequatur itaque aliquid. Quaerat quo ullam architecto dolor sit ad error. Facilis qui veniam dolores alias ea animi excepturi. Dolorem voluptatem provident quas eligendi reiciendis iusto.', '2019-04-14 09:07:19', '2019-04-14 09:07:19'),
(9, 'Dr.', 'Voluptatem ut laborum consequuntur velit dolores aperiam aut. Sed quia sit vitae et praesentium. Sequi magnam quo sit nisi. Magni magni suscipit rerum ducimus fugit iure ratione. Voluptate est officia iusto ut id autem ut. Quo voluptates placeat beatae itaque. Nisi et quidem nihil. Sint ex aut possimus. Et qui dignissimos eos minus adipisci quo voluptate. Ut incidunt minima dolor quam sequi. Voluptate ex consequatur possimus nulla veritatis.', '2019-04-14 09:07:19', '2019-04-14 09:07:19'),
(10, 'Prof.', 'Rem corrupti quod nemo nam nihil ut quia eos. Explicabo perferendis est placeat iste omnis impedit eligendi. Necessitatibus consectetur nulla magnam dolor culpa. Maiores et neque ex et. Quos optio ut ut rerum et inventore rerum. Nihil rem laborum quibusdam. Quisquam nemo quae autem vitae. Vel saepe architecto eos consequatur vitae ut.', '2019-04-14 09:07:19', '2019-04-14 09:07:19'),
(14, 'Men Shoes', 'Mens Shoes Are lorem ipsum is duumy text for creating web pages', '2019-05-04 14:05:52', '2019-05-04 14:05:52');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Abu Dhabi (United Arab Emirates)', NULL, NULL),
(2, 'Admiralty Islands (Papua New Guinea)', NULL, NULL),
(3, 'Afghanistan', NULL, NULL),
(4, 'Aitutaki, Cook Islands (New Zealand)', NULL, NULL),
(5, 'Ajman (United Arab Emirates)', NULL, NULL),
(6, 'Aland Island (Finland)', NULL, NULL),
(7, 'Albania', NULL, NULL),
(8, 'Alberta (Canada)', NULL, NULL),
(9, 'Alderney (Channel Islands) (Great Britain and Northern Ireland)', NULL, NULL),
(10, 'Algeria', NULL, NULL),
(11, 'Alhucemas (Spain)', NULL, NULL),
(12, 'Alofi Island (New Caledonia)', NULL, NULL),
(13, 'Andaman Islands (India)', NULL, NULL),
(14, 'Andorra', NULL, NULL),
(15, 'Angola', NULL, NULL),
(16, 'Anguilla', NULL, NULL),
(17, 'Anjouan (Comoros)', NULL, NULL),
(18, 'Annobon Island (Equatorial Guinea)', NULL, NULL),
(19, 'Antigua (Antigua and Barbuda)', NULL, NULL),
(20, 'Antigua and Barbuda', NULL, NULL),
(21, 'Argentina', NULL, NULL),
(22, 'Armenia', NULL, NULL),
(23, 'Aruba', NULL, NULL),
(24, 'Ascension', NULL, NULL),
(25, 'Astypalaia (Greece)', NULL, NULL),
(26, 'Atafu (Western Samoa)', NULL, NULL),
(27, 'Atiu, Cook Islands (New Zealand)', NULL, NULL),
(28, 'Australia', NULL, NULL),
(29, 'Austria', NULL, NULL),
(30, 'Avarua (New Zealand)', NULL, NULL),
(31, 'Azerbaijan', NULL, NULL),
(32, 'Azores (Portugal)', NULL, NULL),
(33, 'Bahamas', NULL, NULL),
(34, 'Bahrain', NULL, NULL),
(35, 'Balearic Islands (Spain)', NULL, NULL),
(36, 'Balochistan (Pakistan)', NULL, NULL),
(37, 'Bangladesh', NULL, NULL),
(38, 'Banks Island (Vanuatu)', NULL, NULL),
(39, 'Barbados', NULL, NULL),
(40, 'Barbuda (Antigua and Barbuda)', NULL, NULL),
(41, 'Barthelemy (Guadeloupe)', NULL, NULL),
(42, 'Belarus', NULL, NULL),
(43, 'Belgium', NULL, NULL),
(44, 'Belize', NULL, NULL),
(45, 'Benin', NULL, NULL),
(46, 'Bermuda', NULL, NULL),
(47, 'Bhutan', NULL, NULL),
(48, 'Bismark Archipelago (Papua New Guinea)', NULL, NULL),
(49, 'Bolivia', NULL, NULL),
(50, 'Bonaire (Curacao)', NULL, NULL),
(51, 'Borabora (French Polynesia)', NULL, NULL),
(52, 'Borneo (Indonesia)', NULL, NULL),
(53, 'Bosnia-Herzegovina', NULL, NULL),
(54, 'Botswana', NULL, NULL),
(55, 'Bougainville (Papua New Guinea)', NULL, NULL),
(56, 'Bourbon (Reunion)', NULL, NULL),
(57, 'Brazil', NULL, NULL),
(58, 'British Columbia (Canada)', NULL, NULL),
(59, 'British Guiana (Guyana)', NULL, NULL),
(60, 'British Virgin Islands', NULL, NULL),
(61, 'Brunei Darussalam', NULL, NULL),
(62, 'Buka (Papua New Guinea)', NULL, NULL),
(63, 'Bulgaria', NULL, NULL),
(64, 'Burkina Faso', NULL, NULL),
(65, 'Burma', NULL, NULL),
(66, 'Burundi', NULL, NULL),
(67, 'Caicos Islands (Turks and Caicos Islands)', NULL, NULL),
(68, 'Cambodia', NULL, NULL),
(69, 'Cameroon', NULL, NULL),
(70, 'Canada', NULL, NULL),
(71, 'Canary Islands (Spain)', NULL, NULL),
(72, 'Canton Island (Kiribati)', NULL, NULL),
(73, 'Cape Verde', NULL, NULL),
(74, 'Cayman Islands', NULL, NULL),
(75, 'Central African Republic', NULL, NULL),
(76, 'Ceuta (Spain)', NULL, NULL),
(77, 'Ceylon (Sri Lanka)', NULL, NULL),
(78, 'Chad', NULL, NULL),
(79, 'Chaferinas Islands (Spain)', NULL, NULL),
(80, 'Chalki (Greece)', NULL, NULL),
(81, 'Channel Islands (Jersey, Guernsey, Alderney, and Sark) (Great Britain and Northern Ireland)', NULL, NULL),
(82, 'Chile', NULL, NULL),
(83, 'China', NULL, NULL),
(84, 'Christmas Island (Australia)', NULL, NULL),
(85, 'Christmas Island (Kiribati)', NULL, NULL),
(86, 'Cocos Island (Australia)', NULL, NULL),
(87, 'Colombia', NULL, NULL),
(88, 'Comoros', NULL, NULL),
(89, 'Congo, Democratic Republic of the', NULL, NULL),
(90, 'Congo, Republic of the', NULL, NULL),
(91, 'Cook Islands (New Zealand)', NULL, NULL),
(92, 'Corisco Island (Equatorial Guinea)', NULL, NULL),
(93, 'Corsica (France)', NULL, NULL),
(94, 'Costa Rica', NULL, NULL),
(95, 'Cote dâ€™Ivoire', NULL, NULL),
(96, 'Crete (Greece)', NULL, NULL),
(97, 'Croatia', NULL, NULL),
(98, 'Cuba', NULL, NULL),
(99, 'Cumino Island (Malta)', NULL, NULL),
(100, 'Curacao (includes Bonaire, Saba, and Sint Eustatius)', NULL, NULL),
(101, 'Cyjrenaica (Libya)', NULL, NULL),
(102, 'Cyprus', NULL, NULL),
(103, 'Czech Republic', NULL, NULL),
(104, 'Dahomey (Benin)', NULL, NULL),
(105, 'Damao (India)', NULL, NULL),
(106, 'Danger Islands (New Zealand)', NULL, NULL),
(107, 'Denmark', NULL, NULL),
(108, 'Desirade Island (Guadeloupe)', NULL, NULL),
(109, 'Diu (India)', NULL, NULL),
(110, 'Djibouti', NULL, NULL),
(111, 'Dodecanese Islands (Greece)', NULL, NULL),
(112, 'Doha (Qatar)', NULL, NULL),
(113, 'Dominica', NULL, NULL),
(114, 'Dominican Republic', NULL, NULL),
(115, 'Dubai (United Arab Emirates)', NULL, NULL),
(116, 'East Timor (Timor-Leste)', NULL, NULL),
(117, 'Ecuador', NULL, NULL),
(118, 'Egypt', NULL, NULL),
(119, 'Eire (Ireland)', NULL, NULL),
(120, 'El Salvador', NULL, NULL),
(121, 'Ellice Islands (Tuvalu)', NULL, NULL),
(122, 'Elobey Islands (Equatorial Guinea)', NULL, NULL),
(123, 'Enderbury Island (Kiribati)', NULL, NULL),
(124, 'England (Great Britain and Northern Ireland)', NULL, NULL),
(125, 'Equatorial Guinea', NULL, NULL),
(126, 'Eritrea', NULL, NULL),
(127, 'Estonia', NULL, NULL),
(128, 'Ethiopia', NULL, NULL),
(129, 'Fakaofo (Western Samoa)', NULL, NULL),
(130, 'Falkland Islands', NULL, NULL),
(131, 'Fanning Island (Kiribati)', NULL, NULL),
(132, 'Faroe Islands', NULL, NULL),
(133, 'Fernando Po (Equatorial Guinea)', NULL, NULL),
(134, 'Fezzan (Libya)', NULL, NULL),
(135, 'Fiji', NULL, NULL),
(136, 'Finland', NULL, NULL),
(137, 'Formosa (Taiwan)', NULL, NULL),
(138, 'France', NULL, NULL),
(139, 'French Guiana', NULL, NULL),
(140, 'French Oceania (French Polynesia)', NULL, NULL),
(141, 'French Polynesia', NULL, NULL),
(142, 'French West Indies (Guadeloupe)', NULL, NULL),
(143, 'French West Indies (Martinique)', NULL, NULL),
(144, 'Friendly Islands (Tonga)', NULL, NULL),
(145, 'Fujairah (United Arab Emirates)', NULL, NULL),
(146, 'Futuna (Wallis and Futuna Islands)', NULL, NULL),
(147, 'Gabon', NULL, NULL),
(148, 'Gambia', NULL, NULL),
(149, 'Gambier (French Polynesia)', NULL, NULL),
(150, 'Georgia, Republic of', NULL, NULL),
(151, 'Germany', NULL, NULL),
(152, 'Ghana', NULL, NULL),
(153, 'Gibraltar', NULL, NULL),
(154, 'Gilbert Islands (Kiribati)', NULL, NULL),
(155, 'Goa (India)', NULL, NULL),
(156, 'Gozo Island (Malta)', NULL, NULL),
(157, 'Grand Comoro (Comoros)', NULL, NULL),
(158, 'Great Britain and Northern Ireland', NULL, NULL),
(159, 'Greece', NULL, NULL),
(160, 'Greenland', NULL, NULL),
(161, 'Grenada', NULL, NULL),
(162, 'Grenadines (Saint Vincent and the Grenadines)', NULL, NULL),
(163, 'Guadeloupe', NULL, NULL),
(164, 'Guatemala', NULL, NULL),
(165, 'Guernsey (Channel Islands) (Great Britain and Northern Ireland)', NULL, NULL),
(166, 'Guinea', NULL, NULL),
(167, 'Guineaâ€“Bissau', NULL, NULL),
(168, 'Guyana', NULL, NULL),
(169, 'Hainan Island (China)', NULL, NULL),
(170, 'Haiti', NULL, NULL),
(171, 'Hashemite Kingdom (Jordan)', NULL, NULL),
(172, 'Hervey, Cook Islands (New Zealand)', NULL, NULL),
(173, 'Hivaoa (French Polynesia)', NULL, NULL),
(174, 'Holland (Netherlands)', NULL, NULL),
(175, 'Honduras', NULL, NULL),
(176, 'Hong Kong', NULL, NULL),
(177, 'Huahine (French Polynesia)', NULL, NULL),
(178, 'Huan Island (New Caledonia)', NULL, NULL),
(179, 'Hungary', NULL, NULL),
(180, 'Iceland', NULL, NULL),
(181, 'India', NULL, NULL),
(182, 'Indonesia', NULL, NULL),
(183, 'Iran', NULL, NULL),
(184, 'Iraq', NULL, NULL),
(185, 'Ireland', NULL, NULL),
(186, 'Irian Barat (Indonesia)', NULL, NULL),
(187, 'Isle of Man (Great Britain and Northern Ireland)', NULL, NULL),
(188, 'Isle of Pines (New Caledonia)', NULL, NULL),
(189, 'Isle of Pines, West Indies (Cuba)', NULL, NULL),
(190, 'Israel', NULL, NULL),
(191, 'Issas (Djibouti)', NULL, NULL),
(192, 'Italy', NULL, NULL),
(193, 'Ivory Coast (Cote dâ€™Ivoire)', NULL, NULL),
(194, 'Jamaica', NULL, NULL),
(195, 'Japan', NULL, NULL),
(196, 'Jersey (Channel Islands) (Great Britain and Northern Ireland)', NULL, NULL),
(197, 'Johore (Malaysia)', NULL, NULL),
(198, 'Jordan', NULL, NULL),
(199, 'Kalymnos (Greece)', NULL, NULL),
(200, 'Kampuchea (Cambodia)', NULL, NULL),
(201, 'Karpathos (Greece)', NULL, NULL),
(202, 'Kassos (Greece)', NULL, NULL),
(203, 'Kastellorizon (Greece)', NULL, NULL),
(204, 'Kazakhstan', NULL, NULL),
(205, 'Kedah (Malaysia)', NULL, NULL),
(206, 'Keeling Islands (Australia)', NULL, NULL),
(207, 'Kelantan (Malaysia)', NULL, NULL),
(208, 'Kenya', NULL, NULL),
(209, 'Kiribati', NULL, NULL),
(210, 'Korea, Democratic Peopleâ€™s Republic of\r\n        (North Korea)', NULL, NULL),
(211, 'Korea, Republic of (South Korea)', NULL, NULL),
(212, 'Kos (Greece)', NULL, NULL),
(213, 'Kosovo, Republic of', NULL, NULL),
(214, 'Kowloon (Hong Kong)', NULL, NULL),
(215, 'Kuwait', NULL, NULL),
(216, 'Kyrgyzstan', NULL, NULL),
(217, 'Labrador (Canada)', NULL, NULL),
(218, 'Labuan (Malaysia)', NULL, NULL),
(219, 'Laos', NULL, NULL),
(220, 'Latvia', NULL, NULL),
(221, 'Lebanon', NULL, NULL),
(222, 'Leipsos (Greece)', NULL, NULL),
(223, 'Leros (Greece)', NULL, NULL),
(224, 'Les Saints Island (Guadeloupe)', NULL, NULL),
(225, 'Lesotho', NULL, NULL),
(226, 'Liberia', NULL, NULL),
(227, 'Libya', NULL, NULL),
(228, 'Liechtenstein', NULL, NULL),
(229, 'Lithuania', NULL, NULL),
(230, 'Lord Howe Island (Australia)', NULL, NULL),
(231, 'Loyalty Islands (New Caledonia)', NULL, NULL),
(232, 'Luxembourg', NULL, NULL),
(233, 'Macao', NULL, NULL),
(234, 'Macau (Macao)', NULL, NULL),
(235, 'Macedonia, Republic of', NULL, NULL),
(236, 'Madagascar', NULL, NULL),
(237, 'Madeira Islands (Portugal)', NULL, NULL),
(238, 'Malacca (Malaysia)', NULL, NULL),
(239, 'Malawi', NULL, NULL),
(240, 'Malaysia', NULL, NULL),
(241, 'Maldives', NULL, NULL),
(242, 'Mali', NULL, NULL),
(243, 'Malta', NULL, NULL),
(244, 'Manahiki (New Zealand)', NULL, NULL),
(245, 'Manchuria (China)', NULL, NULL),
(246, 'Manitoba (Canada)', NULL, NULL),
(247, 'Marie Galante (Guadeloupe)', NULL, NULL),
(248, 'Marquesas Islands (French Polynesia)', NULL, NULL),
(249, 'Martinique', NULL, NULL),
(250, 'Mauritania', NULL, NULL),
(251, 'Mauritius', NULL, NULL),
(252, 'Mayotte (France)', NULL, NULL),
(253, 'Melilla (Spain)', NULL, NULL),
(254, 'Mexico', NULL, NULL),
(255, 'Miquelon (Saint Pierre and Miquelon)', NULL, NULL),
(256, 'Moheli (Comoros)', NULL, NULL),
(257, 'Moldova', NULL, NULL),
(258, 'Monaco (France)', NULL, NULL),
(259, 'Mongolia', NULL, NULL),
(260, 'Montenegro', NULL, NULL),
(261, 'Montserrat', NULL, NULL),
(262, 'Moorea (French Polynesia)', NULL, NULL),
(263, 'Morocco', NULL, NULL),
(264, 'Mozambique', NULL, NULL),
(265, 'Muscat (Oman)', NULL, NULL),
(266, 'Myanmar (Burma)', NULL, NULL),
(267, 'Namibia', NULL, NULL),
(268, 'Nansil Islands (Japan)', NULL, NULL),
(269, 'Nauru', NULL, NULL),
(270, 'Negri Sembilan (Malaysia)', NULL, NULL),
(271, 'Nepal', NULL, NULL),
(272, 'Netherlands', NULL, NULL),
(273, 'Netherlands Antilles (Curacao)', NULL, NULL),
(274, 'Netherlands Antilles (Sint Maarten)', NULL, NULL),
(275, 'Nevis (Saint Christopher and Nevis)', NULL, NULL),
(276, 'New Britain (Papua New Guinea)', NULL, NULL),
(277, 'New Brunswick (Canada)', NULL, NULL),
(278, 'New Caledonia', NULL, NULL),
(279, 'New Hanover (Papua New Guinea)', NULL, NULL),
(280, 'New Hebrides (Vanuatu)', NULL, NULL),
(281, 'New Ireland (Papua New Guinea)', NULL, NULL),
(282, 'New South Wales (Australia)', NULL, NULL),
(283, 'New Zealand', NULL, NULL),
(284, 'Newfoundland (Canada)', NULL, NULL),
(285, 'Nicaragua', NULL, NULL),
(286, 'Niger', NULL, NULL),
(287, 'Nigeria', NULL, NULL),
(288, 'Nissiros (Greece)', NULL, NULL),
(289, 'Niue (New Zealand)', NULL, NULL),
(290, 'Norfolk Island (Australia)', NULL, NULL),
(291, 'North Borneo (Malaysia)', NULL, NULL),
(292, 'North Korea (Korea, Democratic Peopleâ€™s\r\n        Republic of)', NULL, NULL),
(293, 'Northern Ireland\r\n        (Great Britain and Northern Ireland)', NULL, NULL),
(294, 'Northwest Territory (Canada)', NULL, NULL),
(295, 'Norway', NULL, NULL),
(296, 'Nova Scotia (Canada)', NULL, NULL),
(297, 'Nukahiva (French Polynesia)', NULL, NULL),
(298, 'Nukunonu (Western Samoa)', NULL, NULL),
(299, 'Ocean Island (Kiribati)', NULL, NULL),
(300, 'Okinawa (Japan)', NULL, NULL),
(301, 'Oman', NULL, NULL),
(302, 'Ontario (Canada)', NULL, NULL),
(303, 'Pahang (Malaysia)', NULL, NULL),
(304, 'Pakistan', NULL, NULL),
(305, 'Palmerston, Avarua (New Zealand)', NULL, NULL),
(306, 'Panama', NULL, NULL),
(307, 'Papua New Guinea', NULL, NULL),
(308, 'Paraguay', NULL, NULL),
(309, 'Parry, Cook Islands (New Zealand)', NULL, NULL),
(310, 'Patmos (Greece)', NULL, NULL),
(311, 'Pemba (Tanzania)', NULL, NULL),
(312, 'Penang (Malaysia)', NULL, NULL),
(313, 'Penghu Islands (Taiwan)', NULL, NULL),
(314, 'Penon de Velez de la Gomera (Spain)', NULL, NULL),
(315, 'Penrhyn, Tongareva (New Zealand)', NULL, NULL),
(316, 'Perak (Malaysia)', NULL, NULL),
(317, 'Perlis (Malaysia)', NULL, NULL),
(318, 'Persia (Iran)', NULL, NULL),
(319, 'Peru', NULL, NULL),
(320, 'Pescadores Islands (Taiwan)', NULL, NULL),
(321, 'Petite Terre (Guadeloupe)', NULL, NULL),
(322, 'Philippines', NULL, NULL),
(323, 'Pitcairn Island', NULL, NULL),
(324, 'Poland', NULL, NULL),
(325, 'Portugal', NULL, NULL),
(326, 'Prince Edward Island (Canada)', NULL, NULL),
(327, 'Pukapuka (New Zealand)', NULL, NULL),
(328, 'Qatar', NULL, NULL),
(329, 'Quebec (Canada)', NULL, NULL),
(330, 'Queensland (Australia)', NULL, NULL),
(331, 'Quemoy (Taiwan)', NULL, NULL),
(332, 'Raiatea (French Polynesia)', NULL, NULL),
(333, 'Rakaanga (New Zealand)', NULL, NULL),
(334, 'Rapa (French Polynesia)', NULL, NULL),
(335, 'Rarotonga, Cook Islands (New Zealand)', NULL, NULL),
(336, 'Ras al Kaimah (United Arab Emirates)', NULL, NULL),
(337, 'Redonda (Antigua and Barbuda)', NULL, NULL),
(338, 'Reunion', NULL, NULL),
(339, 'Rio Muni (Equatorial Guinea)', NULL, NULL),
(340, 'Rodos (Greece)', NULL, NULL),
(341, 'Rodrigues (Mauritius)', NULL, NULL),
(342, 'Romania', NULL, NULL),
(343, 'Russia', NULL, NULL),
(344, 'Rwanda', NULL, NULL),
(345, 'Saba (Curacao)', NULL, NULL),
(346, 'Sabah (Malaysia)', NULL, NULL),
(347, 'Saint Barthelemy (Guadeloupe)', NULL, NULL),
(348, 'Saint Bartholomew (Guadeloupe)', NULL, NULL),
(349, 'Saint Christopher and Nevis', NULL, NULL),
(350, 'Saint Helena', NULL, NULL),
(351, 'Saint Kitts (Saint Christopher and Nevis)', NULL, NULL),
(352, 'Saint Lucia', NULL, NULL),
(353, 'Saint Martin (French) (Guadeloupe)', NULL, NULL),
(354, 'Saint Pierre and Miquelon', NULL, NULL),
(355, 'Saint Vincent and the Grenadines', NULL, NULL),
(356, 'Sainte Marie de Madagascar (Madagascar)', NULL, NULL),
(357, 'Salvador (El Salvador)', NULL, NULL),
(358, 'San Marino', NULL, NULL),
(359, 'Santa Cruz Islands (Solomon Islands)', NULL, NULL),
(360, 'Sao Tome and Principe', NULL, NULL),
(361, 'Sarawak (Malaysia)', NULL, NULL),
(362, 'Sark (Channel Islands) (Great Britain and Northern Ireland)', NULL, NULL),
(363, 'Saskatchewan (Canada)', NULL, NULL),
(364, 'Saudi Arabia', NULL, NULL),
(365, 'Savage Island, Niue (New Zealand)', NULL, NULL),
(366, 'Savaii Island (Western Samoa)', NULL, NULL),
(367, 'Scotland (Great Britain and Northern Ireland)', NULL, NULL),
(368, 'Seberang Perai (Malaysia)', NULL, NULL),
(369, 'Selangor (Malaysia)', NULL, NULL),
(370, 'Senegal', NULL, NULL),
(371, 'Serbia, Republic of', NULL, NULL),
(372, 'Seychelles', NULL, NULL),
(373, 'Sharja (United Arab Emirates)', NULL, NULL),
(374, 'Shikoku (Japan)', NULL, NULL),
(375, 'Sierra Leone', NULL, NULL),
(376, 'Sikkim (India)', NULL, NULL),
(377, 'Singapore', NULL, NULL),
(378, 'Sint Eustatius (Curacao)', NULL, NULL),
(379, 'Sint Maarten (Dutch)', NULL, NULL),
(380, 'Slovak Republic (Slovakia)', NULL, NULL),
(381, 'Slovenia', NULL, NULL),
(382, 'Society Islands (French Polynesia)', NULL, NULL),
(383, 'Solomon Islands', NULL, NULL),
(384, 'Somali Democratic Republic (Somalia)', NULL, NULL),
(385, 'Somalia', NULL, NULL),
(386, 'Somaliland (Somalia)', NULL, NULL),
(387, 'South Africa', NULL, NULL),
(388, 'South Australia (Australia)', NULL, NULL),
(389, 'South Georgia (Falkland Islands)', NULL, NULL),
(390, 'South Korea (Korea, Republic of)', NULL, NULL),
(391, 'Spain', NULL, NULL),
(392, 'Spitzbergen (Norway)', NULL, NULL),
(393, 'Sri Lanka', NULL, NULL),
(394, 'Sudan', NULL, NULL),
(395, 'Suriname', NULL, NULL),
(396, 'Suwarrow Islands (New Zealand)', NULL, NULL),
(397, 'Swan Islands (Honduras)', NULL, NULL),
(398, 'Swaziland', NULL, NULL),
(399, 'Sweden', NULL, NULL),
(400, 'Switzerland', NULL, NULL),
(401, 'Symi (Greece)', NULL, NULL),
(402, 'Syrian Arab Republic (Syria)', NULL, NULL),
(403, 'Tahaa (French Polynesia)', NULL, NULL),
(404, 'Tahiti (French Polynesia)', NULL, NULL),
(405, 'Taiwan', NULL, NULL),
(406, 'Tajikistan', NULL, NULL),
(407, 'Tanzania', NULL, NULL),
(408, 'Tasmania (Australia)', NULL, NULL),
(409, 'Tchad (Chad)', NULL, NULL),
(410, 'Thailand', NULL, NULL),
(411, 'Thursday Island (Australia)', NULL, NULL),
(412, 'Tibet (China)', NULL, NULL),
(413, 'Tilos (Greece)', NULL, NULL),
(414, 'Timor (Indonesia)', NULL, NULL),
(415, 'Timor-Leste, Democratic Republic of', NULL, NULL),
(416, 'Tobago (Trinidad and Tobago)', NULL, NULL),
(417, 'Togo', NULL, NULL),
(418, 'Tokelau (Western Samoa)', NULL, NULL),
(419, 'Tonga', NULL, NULL),
(420, 'Tongareva (New Zealand)', NULL, NULL),
(421, 'Tori Shima (Japan)', NULL, NULL),
(422, 'Torres Island (Vanuatu)', NULL, NULL),
(423, 'Trans-Jordan, Hashemite Kingdom (Jordan)', NULL, NULL),
(424, 'Transkei (South Africa)', NULL, NULL),
(425, 'Trengganu (Malaysia)', NULL, NULL),
(426, 'Trinidad and Tobago', NULL, NULL),
(427, 'Tripolitania (Libya)', NULL, NULL),
(428, 'Tristan da Cunha', NULL, NULL),
(429, 'Trucial States (United Arab Emirates)', NULL, NULL),
(430, 'Tuamotou (French Polynesia)', NULL, NULL),
(431, 'Tubuai (French Polynesia)', NULL, NULL),
(432, 'Tunisia', NULL, NULL),
(433, 'Turkey', NULL, NULL),
(434, 'Turkmenistan', NULL, NULL),
(435, 'Turks and Caicos Islands', NULL, NULL),
(436, 'Tuvalu', NULL, NULL),
(437, 'Uganda', NULL, NULL),
(438, 'Ukraine', NULL, NULL),
(439, 'Umm al Quaiwain (United Arab Emirates)', NULL, NULL),
(440, 'Umm Said (Qatar)', NULL, NULL),
(441, 'United Arab Emirates', NULL, NULL),
(442, 'United Kingdom (Great Britain and Northern Ireland)', NULL, NULL),
(443, 'Upolu Island (Western Samoa)', NULL, NULL),
(444, 'Uruguay', NULL, NULL),
(445, 'Uzbekistan', NULL, NULL),
(446, 'Vanuatu', NULL, NULL),
(447, 'Vatican City', NULL, NULL),
(448, 'Venezuela', NULL, NULL),
(449, 'Victoria (Australia)', NULL, NULL),
(450, 'Vietnam', NULL, NULL),
(451, 'Virgin Islands (British)', NULL, NULL),
(452, 'Wales (Great Britain and Northern Ireland)', NULL, NULL),
(453, 'Wallis and Futuna Islands', NULL, NULL),
(454, 'Wellesley, Province (Malaysia)', NULL, NULL),
(455, 'West New Guinea (Indonesia)', NULL, NULL),
(456, 'Western Australia (Australia)', NULL, NULL),
(457, 'Western Samoa', NULL, NULL),
(458, 'Yemen', NULL, NULL),
(459, 'Yukon Territory (Canada)', NULL, NULL),
(460, 'Zafarani Islands (Spain)', NULL, NULL),
(461, 'Zambia', NULL, NULL),
(462, 'Zanzibar (Tanzania)', NULL, NULL),
(463, 'Zimbabwe', NULL, NULL),
(464, '', NULL, NULL),
(465, '', NULL, NULL),
(466, '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `postal_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `first_name`, `last_name`, `address`, `city`, `state`, `postal_code`, `number`, `email`, `country_id`, `created_at`, `updated_at`) VALUES
(1, 'muhammad', 'hussain', 'hyderabad', 'hyderabad', 'sindh', '71000', 33543242, 'hussain@gmail.com', 10, '2019-04-14 13:14:30', '2019-04-14 13:14:30'),
(2, 'sahir', 'sq', 'hyd', 'hyderabad', 'sindh', '7100', 5435, 'sahir@gmail.com', 5, '2019-04-14 13:19:22', '2019-04-14 13:19:22');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `imageable_id` int(10) UNSIGNED NOT NULL,
  `imageable_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `name`, `imageable_id`, `imageable_type`, `created_at`, `updated_at`) VALUES
(1, '1557168103_.jpeg', 101, 'App\\Product', '2019-04-23 08:00:52', '2019-05-06 13:41:43');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(11, '2014_10_12_100000_create_password_resets_table', 1),
(12, '2019_04_04_154329_create_categories_table', 1),
(13, '2019_04_04_162118_create_products_table', 1),
(14, '2019_04_11_144926_create_roles_table', 1),
(15, '2019_04_11_153247_create_countries_table', 1),
(16, '2019_04_11_154122_create_users_table', 1),
(17, '2019_04_11_154230_create_profiles_table', 1),
(18, '2019_04_12_152753_create_customers_table', 1),
(19, '2019_04_12_153951_create_orders_table', 1),
(20, '2019_04_12_201135_create_images_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `price` int(10) UNSIGNED NOT NULL,
  `status` int(10) UNSIGNED NOT NULL,
  `payment_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `product_id`, `quantity`, `price`, `status`, `payment_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 1324, 0, NULL, '2019-04-14 13:14:30', '2019-04-14 13:14:30'),
(2, 2, 1, 1, 1324, 0, NULL, '2019-04-14 13:19:22', '2019-04-14 13:19:22'),
(3, 2, 2, 2, 2430, 0, NULL, '2019-04-14 13:19:22', '2019-04-14 13:19:22'),
(4, 2, 7, 3, 5163, 0, NULL, '2019-04-14 13:19:23', '2019-04-14 13:19:23');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `weight`, `discount`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 'Dr.', 'Nesciunt eos laborum est in. Quaerat iusto quos placeat enim. Earum tempore placeat nulla provident voluptatem molestias adipisci voluptatem. Blanditiis et et alias eum eos delectus dolorem. Qui sit aut et ipsam ad. Voluptatem dolor voluptatum quo blanditiis occaecati inventore accusamus quos. Voluptas rerum explicabo accusamus iste ratione et ad.', 1324, 2157, 57, 10, '2019-04-14 09:07:23', '2019-04-14 09:07:23'),
(2, 'Dr.', 'Nihil ea in voluptatibus. Eligendi ducimus in et dolorem similique. Cum qui nihil animi cumque deleniti minus maxime tempora. Nam vitae sint fugiat est praesentium.', 1215, 1094, 49, 7, '2019-04-14 09:07:23', '2019-04-14 09:07:23'),
(3, 'Mrs.', 'Nostrum ratione voluptatum qui iusto. Voluptatem est sapiente et aut dolorum rerum ipsa. Repudiandae vitae magnam quia mollitia placeat soluta. Voluptatem atque temporibus aut et. Neque et tempora molestias quia ipsum rerum quis.', 1455, 2681, 12, 7, '2019-04-14 09:07:23', '2019-04-14 09:07:23'),
(4, 'Mr.', 'Quos veniam velit veritatis perspiciatis accusamus blanditiis nam. Et veniam voluptatem sint sit maxime ea provident. Sit veniam quia et repellendus qui. Tempora quisquam aliquam dolor aut dolores. Dolorem nemo facilis voluptate repellendus pariatur aut a. Magni incidunt dignissimos aut dicta ipsa incidunt iusto ut.', 2182, 2833, 41, 6, '2019-04-14 09:07:23', '2019-04-14 09:07:23'),
(5, 'Mr.', 'Dolor vero earum consequuntur fugiat nihil accusamus. Esse qui deserunt ut. Nostrum nemo est nisi voluptatem atque quia. Et exercitationem et dolorem quia pariatur maxime. Quo aperiam dolor qui voluptatum ad. Officiis natus velit ut iste illum exercitationem.', 2193, 1011, 45, 6, '2019-04-14 09:07:23', '2019-04-14 09:07:23'),
(6, 'Dr.', 'Qui nobis porro ex temporibus nisi. Similique assumenda minima aut ea. Nihil at repudiandae aut sunt earum. Alias ratione eos similique voluptas qui blanditiis iste. Quos quam iure minima illum nesciunt. Dolor consequatur aspernatur molestiae dolorem.', 1855, 1284, 81, 2, '2019-04-14 09:07:23', '2019-04-14 09:07:23'),
(7, 'Prof.', 'Qui nemo ipsa qui mollitia deleniti illum natus. Dolorem nostrum eligendi consectetur nostrum. Id qui est velit sed dolores praesentium rerum. Placeat maxime rem nobis quia.', 1721, 1141, 67, 3, '2019-04-14 09:07:23', '2019-04-14 09:07:23'),
(8, 'Miss', 'Voluptatem qui dolorem autem qui qui tempore. Unde sapiente vel aliquam sunt corrupti quod. Molestias enim eos neque amet expedita ut necessitatibus. Iure qui vel quia non omnis dicta.', 2067, 443, 19, 6, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(9, 'Prof.', 'Aspernatur atque doloremque officiis nemo delectus voluptatem dolorum. Dolorem iusto iusto id voluptatibus ratione. Pariatur fugiat odit eaque quidem nobis. Consectetur maiores et ut aut corporis voluptatem animi nobis. Excepturi quasi asperiores similique omnis facere. Sequi quaerat non voluptatum laboriosam alias eius est quia. Et necessitatibus nam debitis quo deleniti est tenetur.', 1820, 878, 55, 5, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(10, 'Mr.', 'Ut minus nisi aliquid et voluptatem temporibus et. Eos sequi ea ad hic autem. Adipisci repellat quia vel et nam. Qui ratione rerum alias molestiae tempore. Doloremque dolores numquam minima sunt.', 1585, 408, 57, 6, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(11, 'Prof.', 'Et facere et rem. Dolores dolore ex corporis sed. Qui dignissimos porro tenetur. Id autem quia aperiam non dolor eum consectetur. Quis aut veritatis ut. Id maiores illo minima explicabo.', 2006, 1739, 46, 6, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(12, 'Mr.', 'Ut vel vero consequuntur autem consequatur fuga iure. Explicabo sunt voluptas ullam natus consequatur rerum ipsam. Modi est eos dolorum harum nesciunt earum sunt. In molestiae voluptates sunt quibusdam velit voluptas. Cumque rerum qui blanditiis sit dolores animi dicta.', 2723, 42, 79, 10, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(13, 'Prof.', 'Sit ea a quo qui enim. Inventore facilis facere et enim reprehenderit. Neque exercitationem iusto nesciunt non. Qui enim dolore molestiae dolore in fugit. Aliquid accusantium sequi iste quia. Enim fuga soluta incidunt rerum. Aut quisquam libero autem mollitia laboriosam non animi.', 2306, 2483, 3, 10, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(14, 'Prof.', 'Dolorem esse expedita qui nihil. Inventore ut voluptatem perferendis consectetur ea impedit. Qui iure dolore quis nesciunt quia non quo. Eius sit necessitatibus rem beatae sed repellat. Quis veritatis qui minima dicta quia quaerat.', 1421, 1832, 42, 6, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(15, 'Dr.', 'Magni magnam nihil recusandae sed est. Iste assumenda soluta omnis. Alias unde perferendis culpa occaecati ipsa sint necessitatibus. Quaerat voluptas ratione consequatur doloribus illo.', 2858, 1418, 78, 9, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(16, 'Mr.', 'Placeat voluptatem ipsum voluptatem eligendi error. Non atque vitae expedita. Cupiditate non aut voluptatem quia hic dolores. Ducimus aliquid inventore voluptatem quasi.', 2090, 566, 90, 10, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(17, 'Ms.', 'Sapiente eius sunt odit. Eum aut dolores eos amet aut. Quam corporis voluptatibus eaque maxime. Voluptate ut temporibus aut nam itaque non ipsum reiciendis. Molestiae soluta quis ad error cupiditate fugit sed sed. Error qui in reiciendis quos quam. Dolorum nisi et id delectus occaecati officia.', 1128, 1080, 29, 10, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(18, 'Miss', 'Ut sint sit quae. Sapiente veniam a nobis sed recusandae amet ducimus sint. Neque atque eum sed necessitatibus maxime non enim rerum. Praesentium molestiae voluptatem ea distinctio aut. Quis reprehenderit et facilis vel.', 1689, 1016, 25, 1, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(19, 'Dr.', 'Veniam maiores quia aut aliquid error iusto neque. Ut sed ipsa mollitia nisi impedit. Et quis odio quibusdam recusandae dignissimos. Incidunt aperiam possimus itaque dolore. Sint eum ut sed qui voluptatem. Maxime dolores aut natus.', 2219, 2875, 51, 5, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(20, 'Dr.', 'Fugit velit consectetur saepe aut adipisci. In ipsam et autem molestias officia et. Magni qui qui cum repellat maxime nemo quisquam. Voluptatem eum dicta cupiditate. Officiis quia consequatur ex ut.', 1070, 714, 8, 10, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(21, 'Dr.', 'Id illum excepturi sed fugiat aliquam aliquam. Laborum doloremque enim consequuntur quos officiis. Deleniti occaecati dolores mollitia aliquid placeat dolores laborum. Enim velit modi est dignissimos distinctio totam ab vitae. Eos porro ab occaecati in aut aliquid dicta. Dolores amet illo temporibus labore repellendus.', 1849, 1932, 81, 10, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(22, 'Prof.', 'Reprehenderit ipsum sit vero. Placeat qui ut eius dicta sequi laboriosam et. Eos neque quibusdam enim culpa ea id molestiae provident. Ratione modi voluptatem suscipit et magni numquam voluptates. Sit fuga nihil error.', 2093, 818, 65, 1, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(23, 'Mr.', 'Rem dolores ipsa quas nesciunt neque sunt. Eius beatae ut quo voluptas. Illum neque natus pariatur non earum aut. Fugit sed et non.', 2268, 1392, 13, 1, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(24, 'Miss', 'Quod est sed qui. Nam id et enim dolorem. Nulla quidem quo facere tenetur quo id voluptatem aspernatur. Facilis similique et nihil eveniet non nobis. Aspernatur nihil dolores est perferendis sequi sit explicabo.', 1223, 2433, 71, 8, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(25, 'Dr.', 'Qui nesciunt dolore at est repellat impedit quia consectetur. Aut accusamus ea sed ipsam aut modi eligendi earum. Quod vitae quis dolorem. Est exercitationem omnis repellat laboriosam.', 2902, 643, 88, 9, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(26, 'Dr.', 'Rerum repellendus nam dignissimos voluptas debitis pariatur autem. Facere neque atque sunt sint. Enim quod mollitia vero iusto non. Quis laudantium unde possimus qui. Aut dignissimos dolores doloribus in. Non ipsam et ullam id et veritatis. Praesentium laborum autem tenetur.', 1269, 1659, 62, 9, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(27, 'Mrs.', 'Accusamus beatae exercitationem amet tenetur sint voluptatem quam repudiandae. Sunt qui eum occaecati ut. Cupiditate et ipsa nostrum et possimus sit voluptatem. Voluptatem sit nam quod fugit. Consequatur sint eveniet possimus consequatur nostrum voluptas itaque. Qui quia voluptates odio totam doloremque asperiores veniam perferendis. Magnam suscipit nam maiores exercitationem consectetur sunt itaque.', 2265, 406, 3, 7, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(28, 'Ms.', 'Minus aut nulla voluptatem facere dolorem qui perferendis sit. Sit harum tempore voluptatem non aut assumenda quia. Quia assumenda corrupti velit aut vel. Neque minima dolorum in aperiam sint molestias eos. Delectus accusamus dignissimos ratione culpa quo rerum minima.', 2928, 249, 51, 9, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(29, 'Prof.', 'Autem nam facilis ad corporis occaecati. Animi ut consectetur fugit dolores. Doloribus nam quis similique aut ea iusto. Saepe dicta commodi velit repudiandae qui. Sapiente reprehenderit voluptatem nihil quis labore dignissimos. Aut officia debitis incidunt veritatis omnis nihil occaecati.', 1714, 2053, 13, 10, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(30, 'Dr.', 'Enim occaecati id quam sapiente et aut perspiciatis sequi. Quas illum cumque ipsum. Iste blanditiis quia fuga id non et. Rerum molestiae doloribus consequatur ab perspiciatis et. Debitis qui sint doloremque voluptatibus dolor consequatur.', 2770, 2691, 80, 3, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(31, 'Prof.', 'Delectus consequatur odit ut at. Ad praesentium fugiat iure harum. Quia optio nobis facere rerum assumenda eum sed. Vel qui repellendus ut officia. Placeat et et maxime eaque aliquid.', 1754, 1267, 81, 3, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(32, 'Miss', 'Sed tempore voluptatem consequatur. Pariatur dolor quibusdam accusamus ab. Ut omnis aut exercitationem odit aut sunt. Voluptatem ab consequuntur error similique aspernatur eum minus. Sit alias aut asperiores voluptatum asperiores. Et esse nesciunt culpa non dolorem.', 2736, 973, 44, 1, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(33, 'Ms.', 'Sint beatae deserunt est ut eos. Quibusdam non et blanditiis fugit id ut. Praesentium aut expedita inventore repudiandae. Non quia doloremque qui. Quisquam in laboriosam sit voluptatem. Aliquid ipsa incidunt sit pariatur.', 2147, 90, 81, 7, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(34, 'Dr.', 'Similique neque ut est asperiores pariatur nisi deleniti accusantium. Velit rerum ut ut eos. Neque quia molestias dolore aperiam. Aut repudiandae quia ex illo dolorem illum sit ratione. Et dolorum omnis est voluptas. Vero nostrum et vel ex voluptates est.', 2474, 1350, 62, 3, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(35, 'Prof.', 'Ex id eos vel eveniet. Ipsa quia accusamus quam est dolorum. Sit quia ducimus quia ad sequi accusantium fugit. Non nihil tempore voluptas a. Tempore consequatur voluptatem dolores voluptas est nihil culpa. Repellendus vel eligendi neque aliquid aliquid dolor. Iure consequuntur quia architecto voluptas aut consequatur vitae dolore.', 1985, 2131, 15, 4, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(36, 'Mrs.', 'In fuga eos ut dolores mollitia minus pariatur repudiandae. Autem dolores fuga possimus sit corporis dolorem. Et totam et veniam dolor sit voluptatem ex. Nobis numquam aliquam error repellat et minus tempora.', 2585, 1279, 74, 10, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(37, 'Mr.', 'Consequatur doloribus sapiente magni et. Accusantium deleniti voluptate sit cupiditate vel. Et illum quod esse sed sunt vero. Possimus sed est tempore asperiores error qui. Blanditiis debitis assumenda occaecati earum sit quo tenetur sit.', 1500, 1416, 16, 8, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(38, 'Ms.', 'Nihil earum magnam accusantium et sunt commodi quis provident. Assumenda sed vitae eum eveniet atque aspernatur libero harum. Velit error quae blanditiis mollitia quis magni non. Labore id assumenda laboriosam. Non id et accusamus qui ipsa quibusdam. Repudiandae iure dignissimos est commodi saepe.', 1967, 2429, 16, 6, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(39, 'Mrs.', 'Sint et sed ducimus molestias. Rem odio dignissimos ut. Nihil in rerum in qui adipisci sed officiis. Ipsum iure tempora ut et. Sed eum dolorem quis a porro. Eius quia dignissimos molestias alias facilis id explicabo.', 2485, 2185, 67, 8, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(40, 'Mr.', 'Expedita eum velit et recusandae. Nesciunt ipsam totam beatae et quia. Sint et voluptatem facere nemo esse. Quidem harum et sit beatae blanditiis. Dolorem facere omnis deserunt.', 2406, 154, 86, 9, '2019-04-14 09:07:24', '2019-04-14 09:07:24'),
(41, 'Ms.', 'Dolores sit aut sunt sit dolorem sequi. Eaque vel sequi sapiente optio. Quo et alias voluptatibus eum sit aperiam at. Quas quia numquam minima facilis a voluptas ut. Illo qui qui perspiciatis suscipit. Qui quia voluptas quia consequatur quos iste.', 1713, 2078, 11, 10, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(42, 'Mrs.', 'Vel ut ut molestiae vel ut quibusdam quis voluptates. Suscipit molestiae autem corporis laboriosam rerum. Quidem explicabo quaerat sed earum omnis alias dolorum rerum. Impedit omnis aperiam omnis ut tenetur dolore. Perferendis officiis ea rem fuga.', 2757, 1754, 65, 7, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(43, 'Ms.', 'Iusto sit dolores quis. Ipsum et ipsam vitae quaerat quia dolorem qui. Molestiae dolor consequatur voluptas quasi debitis et iusto. Ratione voluptatem ad qui quidem. Incidunt optio molestiae non ad ea assumenda autem. Debitis cum magni et id.', 1774, 692, 33, 6, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(44, 'Mrs.', 'Perferendis occaecati cumque ad eos. Vitae nulla placeat rerum asperiores odio alias. Enim accusantium cum velit et voluptatem fuga. Dolorem occaecati consequatur non quos. Deleniti deserunt sed ipsum sit sed nulla labore. Quasi at dolorem eos atque voluptate placeat. Beatae nulla labore voluptatem provident sit eaque quia.', 1576, 2892, 41, 5, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(45, 'Dr.', 'Et deserunt est corporis aut est. Delectus quibusdam praesentium itaque quo velit a. Voluptatem veniam beatae laborum ut commodi sunt. Veniam voluptas tempore sequi molestiae nemo. Dolorum praesentium sunt aspernatur odit corrupti voluptatem. Eaque ab unde distinctio explicabo autem veritatis ut tempora. Et rerum exercitationem amet nulla deleniti. Ut sed incidunt ea voluptas dolores aut et.', 1735, 2958, 36, 10, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(46, 'Dr.', 'Aut sit sunt quo tempore. Doloremque vel aut ab atque commodi rerum. Quisquam in magni corporis laboriosam aut. Aspernatur natus ut qui qui. Est ipsa velit perferendis qui pariatur.', 2415, 1304, 72, 10, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(47, 'Prof.', 'Eaque nobis id sint nemo numquam quam voluptatem. Sit ad sunt quidem aliquid est autem vel. Provident sunt beatae ut. Iusto praesentium laborum aut similique suscipit quibusdam non. Totam quia dicta ab et debitis cupiditate.', 1200, 769, 86, 4, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(48, 'Mr.', 'Eum esse unde animi voluptatem quis hic delectus. Et consequatur officia rerum voluptas earum. Error neque tenetur quod similique rerum. Quis sint quis rem ipsum. Nemo sapiente ab rerum debitis. Aut labore numquam earum suscipit amet ducimus quia non. Impedit error temporibus non nam.', 1569, 235, 5, 2, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(49, 'Dr.', 'Quia autem repellendus quam sit. Quibusdam fugit vero eos nisi et ut optio. Numquam molestias asperiores tempore ut laboriosam eos. Error at praesentium cupiditate voluptatum expedita. Omnis asperiores quas autem qui veniam maiores aut. Temporibus iusto maxime libero possimus.', 2672, 2726, 10, 6, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(50, 'Mr.', 'Voluptatem eveniet eveniet optio omnis et molestiae sapiente. Libero unde dicta cupiditate consequatur dolorum voluptate et. Aliquid est vel velit rerum ad a illum. Maxime cum dolorem voluptas omnis.', 2123, 2062, 13, 3, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(51, 'Prof.', 'Maxime consequatur qui iure accusantium officiis neque. Amet alias voluptas et quia. Voluptatem quis qui deserunt quaerat qui corporis. Quia odio modi tempore dignissimos perferendis. Sed deserunt consequuntur aut est voluptatem velit repellendus.', 1158, 317, 81, 3, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(52, 'Dr.', 'Repellat soluta velit quo vitae eligendi laboriosam rerum cupiditate. Voluptas provident repellendus odit maiores. Aliquam enim quisquam excepturi ea aut ut ab. Quaerat vero non pariatur et nemo corrupti dolore. Amet et et eveniet quas.', 2683, 2332, 11, 10, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(53, 'Prof.', 'Possimus ut pariatur in voluptatem in consequatur. Magni quod eum animi illum reiciendis saepe quibusdam hic. Ex est non adipisci et voluptatem ab velit. Molestiae ut quia eius nobis quam. Ut doloremque debitis vel.', 2297, 974, 71, 10, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(54, 'Ms.', 'Nesciunt fuga est deleniti. Inventore mollitia error reprehenderit sint adipisci ad autem dolorem. Suscipit qui ex perspiciatis quidem quo ea sed. Quia tenetur rerum consequatur tenetur consequatur. Repellendus optio sit nemo eius dolorem ad deserunt. Ducimus sed velit qui eveniet quaerat qui. Voluptatem quia quo ad reprehenderit.', 1315, 2693, 14, 10, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(55, 'Dr.', 'Rerum iste est eos quo similique impedit. Nulla temporibus sint blanditiis ratione enim at est. Non minus blanditiis praesentium rerum reiciendis ut aliquam. Voluptatem quis tempore fugit distinctio natus repellat harum reiciendis. Neque omnis distinctio quia commodi.', 2075, 318, 62, 7, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(56, 'Mr.', 'In quis dolore inventore beatae omnis. Nesciunt eum in ullam. Ea ut voluptate vel. Accusantium corporis placeat molestias aspernatur similique dignissimos asperiores iste.', 2035, 1628, 25, 9, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(57, 'Miss', 'Qui ratione eum ullam et fugiat provident dolore. Sit quo adipisci quo qui nihil atque iure pariatur. Autem laborum aliquam qui mollitia fugiat. Sapiente accusantium nulla fugit perferendis saepe distinctio. Quasi est vitae eligendi est occaecati pariatur voluptate. Aut praesentium maiores similique accusantium enim.', 2117, 401, 54, 2, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(58, 'Miss', 'Quia iure numquam nihil laborum. Maxime officiis tenetur illum et officia rerum inventore. Eaque ut neque eaque adipisci sapiente ad. Odio nemo quod laboriosam sed omnis beatae quo. Praesentium dolorem natus architecto tempora rerum quaerat. Earum alias suscipit voluptates et est occaecati dolores.', 2271, 2413, 85, 7, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(59, 'Prof.', 'Architecto sit quas voluptas. Esse vel sed perferendis debitis illum nemo distinctio ut. Occaecati id sequi quibusdam quia accusamus quaerat ut. Repellendus quibusdam similique nihil ut quis aliquid sed. Aut iste ut consequatur fuga nihil dolor. Ut perferendis qui minima perspiciatis enim maxime.', 2775, 358, 11, 5, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(60, 'Ms.', 'Nobis aperiam voluptate et laudantium deserunt est culpa. Vitae neque consectetur totam necessitatibus consequatur enim. Dolorum laudantium earum nemo ex ab. Nobis provident nostrum nihil id ipsum atque. Et eum omnis eum. Quis doloremque sit possimus tenetur officiis officiis. Et vitae sint provident rerum quia incidunt.', 1323, 48, 21, 6, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(61, 'Prof.', 'Qui sequi nulla repellendus voluptatem et. Illo aut qui praesentium dolore neque. Qui qui pariatur praesentium aperiam ad. Facilis voluptatem atque qui odit illo vel ut officiis. Sit soluta excepturi provident cum. Sed voluptas voluptas odio quaerat vitae blanditiis omnis.', 2893, 1352, 5, 10, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(62, 'Dr.', 'Impedit voluptatem cupiditate autem qui distinctio pariatur neque ut. Quam incidunt illo quia ut quia quia et expedita. Odio natus voluptatem sed sint accusantium sed tempore. Reiciendis quasi odit autem necessitatibus ut error. Expedita est culpa cum aliquid consequatur minima suscipit. In officia expedita cum soluta. Nulla consequatur odio earum facilis.', 1198, 207, 63, 7, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(63, 'Mrs.', 'Ipsa sapiente deleniti hic deserunt aperiam ducimus. Et delectus incidunt qui maiores. Quia hic ut magnam accusantium aspernatur. Sapiente ex est eos omnis iste voluptas. Blanditiis quod nobis at modi ea. Praesentium odio dolorum est tempore facere tenetur consequatur.', 2787, 1271, 65, 4, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(64, 'Mrs.', 'Ut tempore repellat accusamus a aspernatur. Et dolor explicabo sapiente adipisci odio. Velit eum vel commodi placeat culpa pariatur earum. Quos accusantium earum incidunt nostrum.', 2403, 657, 80, 3, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(65, 'Ms.', 'Ut quo assumenda laborum sunt. Sint laborum numquam libero expedita ut aut laboriosam. Enim rerum in saepe sunt molestiae aperiam. Sapiente voluptatem ut veniam eum neque eligendi. Ratione maxime enim ut voluptatem temporibus et non. Sed et quaerat quia similique explicabo quisquam.', 2142, 2370, 11, 7, '2019-04-14 09:07:25', '2019-04-14 09:07:25'),
(66, 'Mr.', 'Architecto et aperiam atque omnis quo. Aut dolor consequatur aut repudiandae. Quasi fugiat optio aut ullam explicabo aut ut. Et aut dolor fugit qui. Nemo incidunt aut eos excepturi praesentium omnis et. Quaerat modi quisquam id libero ratione enim. Excepturi sunt explicabo minus vel.', 1676, 1155, 26, 2, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(67, 'Mr.', 'Dolores quas sit alias nisi quos. Sed odio nobis culpa sit ut et qui eum. Dolor omnis dolorum sint commodi ut. Reprehenderit quae eveniet nesciunt aut aut inventore.', 1867, 399, 78, 10, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(68, 'Mr.', 'Earum sed similique nulla perspiciatis et. Possimus iusto blanditiis omnis sit magni est. Animi quos reprehenderit quae et est. Ut ad voluptatem inventore magnam quod. Numquam culpa inventore tempora eum et nostrum. Corporis beatae porro adipisci non nobis mollitia.', 1774, 1329, 34, 6, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(69, 'Mr.', 'Sed a laborum quia. Rerum quisquam rerum aut. Adipisci fugiat adipisci repellat dolorem itaque ullam beatae. Neque rerum sint id et.', 2533, 1479, 47, 10, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(70, 'Dr.', 'Deleniti ad sit modi eos corrupti illum. Itaque dolorem laboriosam asperiores in quis harum. Aut reprehenderit expedita sed dolorem ut soluta. Nobis omnis ut praesentium atque quo maxime amet. Illo nam vero quis autem quia quam quam.', 1424, 146, 82, 7, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(71, 'Prof.', 'Eligendi sit accusamus quos numquam temporibus ut aut tempora. Fuga nostrum accusantium qui esse reiciendis debitis. Cupiditate deserunt harum temporibus qui enim atque. Labore delectus doloremque excepturi pariatur neque vel est. Fuga optio optio eaque ullam.', 2320, 2625, 8, 6, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(72, 'Dr.', 'Unde saepe et neque excepturi tenetur nulla non amet. Dicta in non debitis error a. Quo hic quisquam sit odit minima facilis esse qui. Minima rem suscipit quas distinctio qui mollitia. Est voluptas natus ratione qui repellendus vel consequatur cum. Quasi officiis commodi laudantium sit temporibus.', 1100, 1532, 14, 2, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(73, 'Mrs.', 'Autem et quaerat cupiditate sunt facilis. Eveniet iste libero quam a voluptatem suscipit. Placeat aliquam est facilis. Autem repellat occaecati tempore accusamus. Occaecati quia nisi et et quos ut illum quis. Minima ut architecto doloribus aut rerum fugit.', 2362, 1094, 10, 8, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(74, 'Prof.', 'Consequatur aliquid aut aut quas facere ratione corporis. Beatae qui voluptatem et dolorem enim sunt. Repellat beatae consequatur inventore maiores id. In voluptatem facere rerum voluptate. Vitae id eius dolores sed hic molestiae. Mollitia cumque labore ut fugit nostrum excepturi repudiandae cumque. Voluptas necessitatibus dicta iste quis distinctio soluta tempore.', 1482, 1883, 12, 9, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(75, 'Mr.', 'Consequatur et odit illum officia delectus dolorem. Similique facere commodi quia quod alias voluptatibus vitae. Rem optio et labore rerum eius voluptatum fugit dignissimos. Est consequatur et omnis. Tempore delectus dolorem occaecati qui. Rerum hic iure voluptates ex sint. Saepe recusandae velit quibusdam.', 2760, 301, 46, 5, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(76, 'Miss', 'Aut quasi asperiores fuga et eligendi incidunt quo quae. Hic a nostrum rerum facilis. Et consequatur beatae omnis magnam ut et ut. Fuga iusto culpa blanditiis qui nam ut tempore. Fuga commodi repellat eaque et. Eum iusto voluptas non quasi ut.', 1288, 608, 18, 4, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(77, 'Dr.', 'Consectetur nulla eum dolores asperiores. Dolores soluta molestiae reprehenderit repudiandae cumque voluptatem officia. Quaerat nisi provident sed non exercitationem voluptas. Expedita ut totam harum nobis ullam rerum ex. Aliquid atque officiis excepturi fugiat aliquid. Facilis harum qui omnis provident atque nesciunt. Fugit est corporis quaerat eum eaque quis.', 2599, 2438, 7, 3, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(78, 'Dr.', 'Veniam corrupti minus vel quam consectetur ut itaque. Fuga iste sed qui. Id sapiente unde officiis temporibus suscipit. Incidunt dignissimos vero voluptas voluptatibus. Occaecati pariatur quasi provident facilis. Veritatis qui laboriosam sint consectetur. Voluptatem molestiae quas maxime sit.', 1929, 543, 35, 5, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(79, 'Prof.', 'Ea ea hic voluptatem inventore vel et. Ipsa sed fuga et illo. Vel et ullam mollitia. Libero tenetur dolorum quam placeat vitae provident quasi eum. Molestiae consequatur in et fugiat rem deserunt. Quod voluptatem voluptatem sed adipisci culpa aspernatur nostrum. Incidunt accusamus aliquid illo aut et.', 2756, 1391, 43, 3, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(80, 'Prof.', 'Sequi voluptas laboriosam eum omnis labore. Et perspiciatis quia voluptas possimus eum delectus aut. Eligendi quas tempora omnis omnis illo. Quam architecto voluptas eveniet omnis ea.', 1004, 1983, 73, 1, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(81, 'Prof.', 'Perferendis fugiat maxime vel ad esse odio. Qui a eaque nostrum eos eligendi vitae in. Optio qui ducimus est quidem quisquam. Amet odio aliquid voluptas vel. Voluptas soluta accusamus culpa saepe quo.', 1031, 1242, 89, 6, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(82, 'Dr.', 'Aspernatur qui nihil rerum quia aperiam. Sit reiciendis incidunt cum ut et. Ullam a fugit quam aperiam odio sapiente esse. Sed non veniam veniam sed qui laboriosam veniam. Amet maiores officia est et in hic aliquam.', 2162, 245, 32, 9, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(83, 'Prof.', 'Deleniti est voluptas unde autem dignissimos quos blanditiis. Vitae quisquam suscipit quidem et non. Minus recusandae voluptatem ut aliquam quia velit. Quam aut voluptatem temporibus rerum ea voluptas explicabo minus. Labore repellat quam et dicta ea commodi hic.', 1732, 2935, 88, 8, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(84, 'Ms.', 'Iste culpa voluptas ullam et sapiente. Quasi impedit tenetur sit ut possimus nihil. Commodi asperiores cupiditate ea repudiandae qui. Iure accusamus recusandae quibusdam sit. Ad quo consectetur laborum maxime. Labore qui ipsum autem dolorum. Facere nobis rerum est eum dolores.', 2709, 1183, 81, 9, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(85, 'Mr.', 'Explicabo dolores sunt velit iste ea quas repellendus. Nihil enim consectetur quasi non placeat laudantium et nemo. Voluptates id itaque corporis sit est nulla. Exercitationem hic minus libero illum delectus molestiae optio. Omnis consequatur beatae aut labore ut natus.', 2939, 609, 82, 4, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(86, 'Dr.', 'Numquam voluptas architecto sit voluptatem hic. Dolorum ut saepe quisquam doloremque. Perferendis sed assumenda aliquam voluptatibus repudiandae. Et velit esse doloremque explicabo aperiam perspiciatis odit. Corporis similique ut omnis est aut deserunt.', 1574, 43, 36, 10, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(87, 'Dr.', 'Libero reprehenderit reiciendis consequuntur hic. Velit sed autem omnis sit ipsum ut. Nesciunt repudiandae rerum qui itaque ipsum perspiciatis ducimus. Asperiores fugiat ducimus et voluptatem ea alias quas. Tempora enim libero quisquam rerum necessitatibus. Enim et libero quibusdam iusto eos porro.', 1919, 12, 79, 10, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(88, 'Prof.', 'Eum enim commodi magni minus vel. Eos suscipit libero aut optio voluptatem. Qui eveniet doloremque qui aut non et. Ut laudantium sed saepe voluptatibus occaecati enim debitis.', 1050, 2499, 84, 3, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(89, 'Mr.', 'Quae nemo expedita rem earum corporis consectetur quis nesciunt. Labore repellat quisquam repudiandae quo voluptatum laudantium non. Id blanditiis ipsam iure commodi. Natus molestiae adipisci eum provident suscipit. Et voluptas quo atque accusantium est.', 2202, 1413, 4, 9, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(90, 'Miss', 'Eligendi dolorum autem dignissimos rerum quis. Quia vitae debitis sit animi aliquid delectus nobis. Et minima consequuntur eveniet qui. Reprehenderit corrupti praesentium animi ratione ea dolore. Culpa sed mollitia qui placeat. Qui iusto enim excepturi a vitae sit modi. Eos a et voluptates qui nobis porro.', 1569, 1306, 65, 1, '2019-04-14 09:07:26', '2019-04-14 09:07:26'),
(91, 'Mrs.', 'Corrupti quas maiores dolorum est nobis. Modi molestias possimus non ullam facilis tenetur praesentium. Harum illo aut et. Et mollitia cum dolores nihil. Consequatur quia ut quam.', 2119, 2314, 27, 3, '2019-04-14 09:07:27', '2019-04-14 09:07:27'),
(92, 'Mr.', 'Autem facilis ducimus quia. Temporibus minima aut eaque. Ea magnam voluptatum sit ipsum. Maiores tenetur qui aliquid autem quis. Non magnam blanditiis eum. Dolorem explicabo repellendus ut et aut voluptas tenetur. Est voluptas dolores asperiores dolor non.', 2000, 1699, 6, 2, '2019-04-14 09:07:27', '2019-04-14 09:07:27'),
(93, 'Prof.', 'Veniam neque autem molestiae aspernatur. Est et repudiandae aut quas itaque voluptatem sint. Quam debitis tempora ut labore mollitia cupiditate laudantium. Veniam quo enim error. Illum ut ex est et explicabo sit. Ad unde reprehenderit qui error vero minus consequatur aperiam.', 1808, 2495, 30, 7, '2019-04-14 09:07:27', '2019-04-14 09:07:27'),
(94, 'Dr.', 'Est reiciendis voluptatum sit necessitatibus et dignissimos quia explicabo. Error rerum libero eum id. Quo minus neque et et. Impedit est a dolor error. Error quis voluptas aut reiciendis ut.', 2332, 870, 24, 10, '2019-04-14 09:07:27', '2019-04-14 09:07:27'),
(95, 'Prof.', 'Ab assumenda aut dolore eos sunt. Aut aut aut et veniam ut. Esse enim sit quidem hic qui. Facilis distinctio sed voluptatem distinctio sit consectetur. Et eos non asperiores asperiores vitae.', 2238, 232, 22, 9, '2019-04-14 09:07:27', '2019-04-14 09:07:27'),
(96, 'Dr.', 'Nostrum praesentium tempore quisquam rem. Sapiente quo sunt ipsam sed hic labore. Ea quidem odit facilis voluptate. A rerum officia voluptatem est voluptas. Nulla qui reprehenderit consequatur.', 2520, 2937, 62, 5, '2019-04-14 09:07:27', '2019-04-14 09:07:27'),
(97, 'Miss', 'Eum mollitia iusto eveniet cumque sed fugit veniam. Vel sed distinctio architecto ipsa totam. Debitis quaerat hic dolore inventore et quam. Harum qui iusto quod est totam.', 1618, 1611, 66, 2, '2019-04-14 09:07:27', '2019-04-14 09:07:27'),
(98, 'Mr.', 'Minima quos sit et. Iusto deleniti repellat eum consequuntur. Molestias ut nobis dolorem dolores cumque fugiat. Laborum quisquam ut rerum minus aliquam saepe. Omnis sit itaque tempore atque et perferendis. Rerum et commodi soluta quas fugit nam.', 1288, 1470, 76, 2, '2019-04-14 09:07:27', '2019-04-14 09:07:27'),
(99, 'Dr.', 'Possimus quis beatae ut et. Ut illo asperiores maxime aliquam sed assumenda. Est in doloribus sunt dolores est. Perspiciatis vel quia voluptatem qui. Sit qui nisi aperiam necessitatibus rem aut omnis. Aliquid nulla et est explicabo ipsa id. Voluptas distinctio minima est voluptatibus.', 2676, 2484, 7, 1, '2019-04-14 09:07:27', '2019-04-14 09:07:27'),
(100, 'Mrs.', 'Dicta in itaque in occaecati debitis et. Ducimus recusandae qui qui nobis ut harum. Quibusdam vel necessitatibus perferendis unde aut vero beatae. Dicta incidunt aut pariatur quaerat.', 1644, 627, 15, 9, '2019-04-14 09:07:27', '2019-04-14 09:07:27'),
(101, 'Brazers', 'lorem ipsum is dummy text for', 3000, 22, 1, 2, '2019-04-23 08:00:52', '2019-05-01 07:26:26');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `postal_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `first_name`, `last_name`, `country_id`, `state`, `city`, `postal_code`, `address`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Muhammad ', 'Hussain', 10, 'Sindh', 'Hyderabad', '71000', 'hyderabad sindh', 2, '2019-04-19 19:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', '2019-04-19 19:00:00', '2019-04-19 19:00:00'),
(2, 'Editor', '2019-04-19 19:00:00', '2019-04-19 19:00:00'),
(3, 'User', '2019-04-19 19:00:00', '2019-04-19 19:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL DEFAULT '3',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, 'hussain', 'hussain@gmail.com', '$2y$10$JMK0rNeZ9RWQSTZp7S2NB.xdESIzw3YjC1hgImfwwZjb1Jq1x0YRS', 1, 'bNxfDBpfpzl9knA7zPyknv4zp2mGxbZCKNFNvnVw7vmdQanpugvq8NewE4R4', '2019-04-19 14:08:56', '2019-04-19 14:08:56'),
(3, 'sahir', 'sahir@gmail.com', '$2y$10$XIxoq13Z6yi/LrWEs2K3BeHK3jQE2IXu8sXdb7nE2CEmOWHmNYAf6', 3, 'EKoQgQqdaM7h1VgItx02z5y30rzpNeiIC7AHLVj1L7nZvj05q0K7dhAholqB', '2019-04-19 15:14:50', '2019-04-19 15:14:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customers_country_id_foreign` (`country_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `images_imageable_id_foreign` (`imageable_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profiles_user_id_foreign` (`user_id`),
  ADD KEY `profiles_country_id_foreign` (`country_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=467;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`);

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_imageable_id_foreign` FOREIGN KEY (`imageable_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `profiles_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`),
  ADD CONSTRAINT `profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
