<?php $__env->startSection('content'); ?>


<div class="container-fluid ">
	
	<div class="container">
		
		<div class="row">
			
			<div class="col-lg-2">
				
				<?php echo $__env->make('Admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			</div>

			<div class="col-lg-8">

				<?php if(session()->has('message')): ?>
						<p class="alert alert-success"><?php echo e(session()->get('message')); ?></p>
					<?php endif; ?>

				<a href="<?php echo e(route('categories.create')); ?>" class="btn-success btn btn-sm pull-right" style="margin-bottom: 40px;">Add New Category</a>

				
				<table id="myTable" class="display">
    <thead>
        <tr>
        	<th>Sno</th>
            <th>Name</th>
            
            <th>Delete</th>
            <th>View</th>

        </tr>
    </thead>
    <tbody>
    	<?php $sno=1; ?>
    	<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	
        <tr>
        	
        	<td><?php echo e($sno++); ?></td>
            
            <td><?php echo e($category->name); ?></td>
            
            <td><a href="#" 
            	onclick="
            	var result = confirm('Are You Sure You Want TO Delete Category');
            	if (result) {
            		event.preventDefault();
            		document.getElementById('delete-form').submit();
            	}
            	" 
             class="btn btn-danger btn-sm">Delete</a>

             <form action="<?php echo e(route('categories.destroy' , [$category->id])); ?>" name="delete-form" id="delete-form" method="post">
             	<?php echo e(csrf_field()); ?>


             	<input type="hidden" name="_method" value="Delete">
             </form>

         </td>
            <td><a href="" class="btn btn-success btn-sm">View  Category</a></td>
               
        </tr>
 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>

			</div>

		</div>

	</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>