<?php $__env->startSection('content'); ?>


<div class="container-fluid ">
	
	<div class="row">
		<div class="col-lg-2" style="margin-top: 22px;">

          <?php echo $__env->make('Admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col-lg-7">


        	<h2 class="text-left">Edit Product <?php echo e($product->name); ?> Of Category: (<?php echo e($product->category->name); ?>)</h2>


        	<form class="col-md-10" style="margin-top: 30px;" action="<?php echo e(url('updateproduct')); ?>" method="post">
        		<?php echo e(csrf_field()); ?>

        		
        		
        		<h4>Product Name</h4>
        		<input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control">

        		<input type="hidden" name="id" value="<?php echo e($product->id); ?>">

        		<h4>Product Category</h4>
        		<select name="category" class="form-control">
        			<option value="<?php echo e($product->category->id); ?>"><?php echo e($product->category->name); ?></option>
        			<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        			<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</select>

        		<h4>Product Description</h4>
        		<textarea style="height: 200px;" name="description" class="form-control"><?php echo e($product->description); ?></textarea>

        		<h4>Product Price</h4>
        		<input type="number" name="price" value="<?php echo e($product->price); ?>" class="form-control">

        		

        		<h4>Product Discount <span style="font-size: 14px;">Choose Just In Percent %</span></h4>
        		<select name="discount" class="form-control">
        			<?php for($d=1; $d<=100 ; $d++): ?>
        			<option value="<?php echo e($d); ?>"><?php echo e($d); ?></option>
        			<?php endfor; ?>
        		</select>

        		<h4>Product Weight <span style="font-size: 14px;">Enter Weight In Grams</span></h4>
        		<input type="number" name="weight" value="<?php echo e($product->weight); ?>" class="form-control">

        		<input style="margin-top: 30px;" type="submit" name="submit" value="Edit Product" class="btn btn-success btn-md form-control">






        	</form>
        		


        </div>

        <div class="col-lg-2 text-left" style="margin-top: 30px;">

        	<h4 class="text-left">Update Product Image</h4>

        	<?php if(session()->has('message')): ?>
						<p class="alert alert-success"><?php echo e(session()->get('message')); ?></p>
					<?php endif; ?>
        	<img width="100%" class="img-responsive" src="<?php echo e(asset('public/img/'.$product->image['name'])); ?>">

        	<form action="<?php echo e(url('updateproductimage')); ?>" method="post" enctype="multipart/form-data">
        		<?php echo e(csrf_field()); ?>

        		<input type="hidden" name="id" value="<?php echo e($product->image['id']); ?>">
        		<input type="file" name="image" class="form-control">
        		<input type="submit" name="submit" value="Update Image" class="btn btn-success form-control">
        	</form>
        </div>

    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>