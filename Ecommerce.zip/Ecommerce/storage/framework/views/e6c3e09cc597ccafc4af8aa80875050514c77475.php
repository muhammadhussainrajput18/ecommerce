<?php $__env->startSection('content'); ?>



			

			<div class="container">
				<div class="row">
					
					<?php if(session()->has('message')): ?>
						<p class="alert alert-success"><?php echo e(session()->get('message')); ?></p>
					<?php endif; ?>
					<div class="col-lg-4"></div>

					<div class="col-lg-8">
						
						<h2><?php echo e($product->name); ?></h2>
						<p><?php echo e($product->description); ?></p>

						<?php if($product->discount): ?>
							<h4><strong>Original Price</strong> <del><?php echo e($product->price); ?></del></h4>

							<h4><strong>Discounted Price Is</strong> <span><?php echo e(floor($product->price * ((100-$product->discount) / 100 ))); ?></span></h4>

							<h5><strong>Off</strong>      <?php echo e($product->discount); ?>%</h5>

							<?php else: ?>
							<h4><strong>Price</strong> <?php echo e($product->price); ?></h4>


						<?php endif; ?>

							<p>Product Catogary : <?php echo e($product->category->name); ?></p>

							<a href="<?php echo e(route('addToCart',$product)); ?>">Add Cart</a>
						

					</div>


				</div>
			</div>
		


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>