<?php $__env->startSection('content'); ?>

	<div class="container-fluid upload-products">
	
	<div class="row">
		<div class="col-lg-2" style="margin-top: 22px;">

          <?php echo $__env->make('Admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col-lg-10">

        	<table id="myTable" class="display">
    <thead>
        <tr>
        	<th>Sno</th>
            <th>Image</th>
            <th>Product Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Weight</th>
            <th>view</th>

        </tr>
    </thead>
    <tbody>
    	<?php $sno=1; ?>
    	<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	
        <tr>
        	
        	<td><?php echo e($sno++); ?></td>
            <td><img width="10%" class="img-responsive" src="<?php echo e(asset('public/img/'.$product->image['name'])); ?>"></td>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->category->name); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td><?php echo e($product->discount); ?></td>
            <td><?php echo e($product->weight); ?></td>
            <td><a href="<?php echo e(url('Showproduct',$product->id)); ?>" class="btn btn-success btn-sm">View Product</a></td>
               
        </tr>
 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>

        </div>


    </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>