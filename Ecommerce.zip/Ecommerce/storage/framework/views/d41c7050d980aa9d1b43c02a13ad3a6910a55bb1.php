<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>


                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container-fluid">
    <div class="row">
        
        <div class="col-lg-offset-1 col-lg-2">


            
          <?php echo $__env->make('Admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>


        <div class="col-md-6">
            
           

            <table style="height: 600px;"  width="100%" class="table table-responsive">

                <tr style="background: #3097d1; color: white;">
                    <td colspan="2"><h3 class="text-center" style="text-transform: capitalize;" >Profile  <?php echo e(Auth::user()->name); ?></h3></td>
                </tr>

                <tr>
                    <td><label>User Name</label></td>
                    <td><span><?php echo e(Auth::user()->name); ?></span></td>
                </tr>


                <tr>
                    <td><label>Email</label></td>
                    <td><span><?php echo e(Auth::user()->email); ?></span></td>
                </tr>

                    <?php if(Auth::user()->profile): ?>
                <tr>
                    <td><label>First Name</label></td>
                    <td><span><?php echo e(Auth::user()->profile->first_name); ?></span></td>
                </tr>


                 <tr>
                    <td><label>Last Name</label></td>
                    <td><span><?php echo e(Auth::user()->profile->last_name); ?></span></td>
                </tr>

                 <tr>
                    <td><label>Country</label></td>
                    <td><span><?php echo e(Auth::user()->profile->country->name); ?></span></td>
                </tr>

                 <tr>
                    <td><label>State</label></td>
                    <td><span><?php echo e(Auth::user()->profile->state); ?></span></td>
                </tr>

                 <tr>
                    <td><label>City</label></td>
                    <td><span><?php echo e(Auth::user()->profile->city); ?></span></td>
                </tr>

                 <tr>
                    <td><label>Address</label></td>
                    <td><span><?php echo e(Auth::user()->profile->address); ?></span></td>
                </tr>

                 <tr>
                    <td><label>Account Status</label></td>
                    <td><span><?php echo e(Auth::user()->role->name); ?></span></td>
                </tr>

                <?php else: ?>

                <tr>
                    <td colspan="2"><br><span class="col-lg-12  alert alert-success">Create Profile</span></td>
                </tr>



                <?php endif; ?>

               

                
            </table>

           

            

           

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>