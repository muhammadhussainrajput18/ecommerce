<?php $__env->startSection('content'); ?>


<div class="container">
	<h1>Cart</h1>

	<?php if(isset($cart) && $cart->getContents()): ?>

	<div class="table table-responsive">
			
			<table class="table text-muted">
				<tr>
				<th>Product Image</th>
				<th>Product Name</th>
				<th>Product Quantity</th>
				<th>Product Price</th>
				<th>Action</th>
			</tr>

			<?php $__currentLoopData = $cart->getContents(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><img src="" /></td>

				<td><?php echo e($product['product']->name); ?></td>

				<td>
					<form action="<?php echo e(route('update',$product)); ?>" method="post">
							<?php echo e(csrf_field()); ?>

						<input type="number"  name="qty" id="qty" class="form-control text-center" min="0" max="99" value="<?php echo e($product['qty']); ?>">
						<input type="submit" name="update" class="form-control btn btn-success">

					</form>
				</td>

				<td>
					<h3><?php echo e($product['price']); ?></h3>
				</td>

				<td>
					<form action="<?php echo e(route('remove', $product)); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<input type="submit" name="remove" value="x Remove" class="form-control btn btn-danger">

					</form>
				</td>

			</tr>


			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<tr>
				<td colspan="2" >Total Quantity : </td>
				<td class="text-center"><?php echo e($cart->getTotalQty()); ?></td>

			</tr>

			<tr>
				<td colspan="3">Total Price : </td>
				<td class="text-center"><?php echo e($cart->getTotalPrice()); ?></td>

			</tr>

			<tr>
				<td><a href="<?php echo e(url('checkout')); ?>" class="btn btn-success btn-lg">Checkout</a></td>
			</tr>
			</table>

	</div>

	<?php else: ?>

		<p class="alert alert-danger">No Product in your cart</p>

	<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>