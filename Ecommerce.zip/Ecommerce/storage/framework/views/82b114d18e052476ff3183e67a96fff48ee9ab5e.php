 <div class="list-group">
  <a href="#" class="list-group-item active">
    Menu
  </a>
  <a href="#" class="list-group-item">Profile</a>
  <a href="<?php echo e(route('categories.index')); ?>" class="list-group-item ">Categories</a>
  <a href="<?php echo e(route('products.create')); ?>" class="list-group-item">Upload Products</a>
  <a href="<?php echo e(url('Allproducts')); ?>" class="list-group-item">All Products</a>
  <a href="#" class="list-group-item">Edit Categories</a>
  <a href="#" class="list-group-item">Users</a>

</div>