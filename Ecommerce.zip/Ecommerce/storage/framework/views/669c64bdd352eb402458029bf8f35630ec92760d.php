<?php $__env->startSection('content'); ?>


<div class="container-fluid upload-products">
	
	<div class="row">
		<div class="col-lg-offset-1 col-lg-2" style="margin-top: 22px;">

          <?php echo $__env->make('Admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col-lg-6">

        	<?php if(session()->has('message')): ?>
						<p class="alert alert-success"><?php echo e(session()->get('message')); ?></p>
					<?php endif; ?>
        	
        	<h3 class="" style="background: #3097d1; padding: 20px; color: white">Upload Products</h3>

        	<form action="<?php echo e(route('products.store')); ?>" method="post" enctype="multipart/form-data">
        		<?php echo e(csrf_field()); ?>


        		<h4>Product Name</h4>
        		<?php if($errors->get('name')): ?>
                <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="label label-danger"><?php echo e($message); ?></span>
                <br>
        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php endif; ?>
                 <input type="text" name="name" placeholder="Product name" class="form-control">

        		<h4>Select Product Category</h4>
        		<select name="category" class="form-control">
        			<option value="">Select Category</option>
        			<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        			<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</select>

        		<h4>Product Description</h4>
        		<textarea placeholder="Product description" style="height: 200px;" name="description" class="form-control"></textarea>

        		<h4>Product Original Price</h4>
        		<input type="number" name="price" placeholder="Product Price" class="form-control">

        		<h4>Product Discount Price</h4>
        		<input type="number" name="discount" placeholder="Product Discount Price" class="form-control">

        		<h4>Product weight</h4>
        		<input type="number" name="weight" placeholder="Product Weight in grams" class="form-control">

        		

        		

        		<h4>Uplaod Product Image</h4>
        		<input type="file" name="image" class="form-control">

        		<br>


        		<input type="submit" style="background: #3097d1;" name="submit" value="Upload Product" class="btn btn-success btn-md form-control">





        	</form>

        </div>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>