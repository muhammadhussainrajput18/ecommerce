<?php $__env->startSection('content'); ?>



<?php echo $__env->make('includes.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<div class="container-fluid">
	<div class="row">
		
		<div class="col-lg-3">
			
			<h3>Catogries</h3>

			<ul>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><a href=""><?php echo e($category->name); ?></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>

		</div>


		<div class="col-lg-9">
			
			<div class="row">
				<h4>Recent Products</h4>


				
			</div>

			
			<div class="row">
				<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-3">
					<a href="<?php echo e(route('products.show', [$products->id])); ?>">
					<img width="100%" class="img-responsive" src="<?php echo e(asset('public/images/ladies/11.jpg')); ?>">
					<h3><?php echo e($products->name); ?></h3>
				</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			
		</div>

	</div>
</div>

<!-- <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<h3><?php echo e($products->name); ?></h3>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>