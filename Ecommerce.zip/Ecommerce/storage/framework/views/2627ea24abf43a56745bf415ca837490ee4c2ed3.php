<?php $__env->startSection('content'); ?>

<div class="container-fluid upload-products">
	
	<div class="row">
		<div class="col-lg-2" style="margin-top: 22px;">

          <?php echo $__env->make('Admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col-lg-6">
        	<?php if(session()->has('message')): ?>
						<p class="alert alert-success"><?php echo e(session()->get('message')); ?></p>
					<?php endif; ?>

        	<h2>Add New Category</h2>
        	<br><br>
        	<form action="<?php echo e(route('categories.store')); ?>"  method="post" >

        		<?php echo e(csrf_field()); ?>

        		
        		<h4>Category Name</h4>
        		<input type="text" name="name" class="form-control">


        		<h4>Category Description</h4>
        		<textarea name="description" class="form-control" style="height: 200px"></textarea>

        		<br>

        		<input type="submit" name="submit" class="form-control btn btn-success">
        	</form>

        </div>


    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>