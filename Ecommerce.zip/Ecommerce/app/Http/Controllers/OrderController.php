<?php

namespace App\Http\Controllers;

use App\Order;
use App\Cart;
use App\Country;
use App\Customer;
use Illuminate\Http\Request;
use DB;
use Session;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $country= Country::all();
        if (!Session::has('cart')) {
            return view('Products.cart');

        }

         $cart= Session::get('cart');
        
        return view('Products.checkout', ['cart'=>$cart , 'country'=>$country]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

           $validatedData = $request->validate([
        'country' => 'required',
        'first_name' => 'required',
        'last_name' => 'required',
        'address' => 'required',
        'city' => 'required',
        'state' => 'required',
        'zip_code' => 'required',
        'phone_number' => 'required',
        'email_address' => 'required',
        
    ]);

           if ($validatedData) {

          

               if (Session::has('cart')) {
                $cart= Session::get('cart');

               
                DB::beginTransaction();
                    $customer= Customer::create([
                           
                          "first_name" => $request->input('first_name'),
                          "last_name" => $request->input('last_name'),
                          "address" => $request->input('address'),
                          "city" => $request->input('city'),
                          "state" => $request->input('state'),
                          "postal_code" => $request->input('zip_code'),
                          "number" => $request->input('phone_number'),
                          "email" => $request->input('email_address'),
                          "country_id" => $request->input('country'),
                    ]);

                    
                    foreach($cart->getContents() as $id=>$product){
                            $items=[
                                'customer_id'=>$customer->id,
                                'product_id'=>$product['product']->id,
                                'quantity'=>$product['qty'],
                                'price'=>$product['price'],
                                'status'=> '0',

                            ];
                  

                    $order= Order::create($items);

                          } 
                          if ($customer && $order) {
                              DB::commit();
                              return redirect('products');
                          }
                          else{
                            DB::rollback();
                            return back()->withInput();
                          }
                          
                   
                
               }

               else{
                return redirect()->withInput()->with('message' , 'Your Cart is empaty');
               }
                

           }


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function show(Order $order)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        //
    }
}
