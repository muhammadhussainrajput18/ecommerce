<?php

namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        $category= Category::all();
        return view('Admin.category' , ['category'=>$category ]);

        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //


        return view('Admin.createcategory');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

          $validatedData = $request->validate([

            'name' => 'required',
            'description' => 'required'

          ]); 


          if ($validatedData) {
              
              $CreateCategory= Category::create([

                'name'=>$request->input('name'),
                'description'=>$request->input('description'),



              ]);


              if ($CreateCategory) {
                  
                  return redirect()->back()->with('message' , 'category added successfully');
              }

              else {
                  return back()->withInput();
              }
          }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(Category $category)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function edit(Category $category)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Category $category)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function destroy(Category $category)
    {
        //

        $category=Category::find($category->id);

        if ($category->delete()) {
            return redirect()->back()->with('message' , 'category has been deleted successfully');

        }

        else{
            return redirect()->back()->with('message' , 'category not deleted successfully');
        }
    }
}
