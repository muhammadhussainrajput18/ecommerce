<?php

namespace App\Http\Controllers;
use App\User;
use App\Product;
use App\Image;
use App\Category;
use App\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $product=Product::all();
        $category=Category::all();
        return view('Products.index',['product'=>$product, 'categories'=>$category]);
    }

    public function showproductstoadmin(){
        if (Auth::check()) {
            # code...
    
        if (Auth::user()->role->id==1) {
             $product=Product::all();
            
            return view('Admin.products',['product'=>$product]);
        }
        else{
            return redirect('/');
        }

            }
    }


    public function showproduct(Product $product){
         if (Auth::check()) {
            # code...
    
        if (Auth::user()->role->id==1) {
             $product=Product::find($product->id);
            
            return view('Admin.product',['product'=>$product]);
        }
        else{
            return redirect('/');
        }

            }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */




    public function addToCart(Product  $product , Request $request){

            $oldCart= Session::has('cart') ? Session::get('cart') : null ;
            $qty= $request->qty ? $request->$qty : 1;

            $cart = new Cart($oldCart);
            $cart->addProduct($product, $qty);
            Session::put('cart' , $cart);
            return back()->with('message', "Product $product->name has been successfully added ");
    }


    public function Cart(){
        if (!Session::has('cart')) {
            return view('Products.cart');

        }

        $cart= Session::get('cart');
        return view('Products.cart', ['cart'=>$cart]);
    }


    public function removeProduct(Product $product){
            $oldCart= Session::has('cart') ? Session::get('cart') : null ;
            $cart = new Cart($oldCart);
            $cart->removeProduct($product);
            Session::put('cart', $cart);
            return back()->with('message', "Product $product->name has been successfully added " );

    }

    public function updateProduct(Product $product, Request $request ){
                $oldCart= Session::has('cart') ? Session::get('cart') : null ;
                $cart= new Cart($oldCart);
                $cart->updateProduct($product, $request->qty);
                session::put('cart', $cart);
                return back()->with('message', "Product $product->name has been successfully updated " );
    }


    

    public function create()
    {
        //
         if (Auth::user()->role->id==1) {
        $category=Category::all();
        return view('Admin.createproduct' , ['category'=>$category]);
        }


    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

       
         if (Auth::user()->role_id==1) {
                $validation =$request->validate([

                    'name' => 'required',
                    'category' => 'required',
                    'description' => 'required',
                    'price' => 'required',
                    'weight' => 'required',
                    'image' => 'required',


                ]);

                if ($validation) {
                        if ($request->hasFile('image') && $request->image->isValid()) {
                            $extention= $request->image->extension();
                            $filename= time()."_.".$extention;
                            $request->image->move(public_path('img'),$filename);
                        }

                        else{
                            $filename= 'no-image.png';
                        }

                        $productupload= product::create([
                            'name'=>$request->input('name'),
                            'description'=>$request->input('description'),
                            'price'=>$request->input('price'),
                            'weight'=>$request->input('weight'),
                            'discount'=>$request->input('discount'),
                            'category_id'=>$request->input('category'),

                        ]);

                        $product_img=image::create([
                            'name'=>$filename,
                            'imageable_id'=>$productupload->id,
                            'imageable_type'=>'App\Product'
                        ]);

                        if ($productupload) {
                            return back()->with('message', 'Product Has been uploaded');
                        }

                }

                else{
                    return back()->withInput();
                }
         }
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        $product= Product::find($product->id);

        return view('Products.show' , ['product'=>$product]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //

         $product= Product::find($product->id);
         $category=Category::all();
        return view('Admin.editproducts' , ['product'=>$product , 'category'=>$category] );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //

        // $validation=$request->validate([

        //             'name' => 'required',
        //             'category' => 'required',
        //             'description' => 'required',
        //             'price' => 'required',
        //             'weight' => 'required',

        // ]);


        // if ($validation) {
             
             $productupdate= Product::where('id', $request->input('id'))->update([

                    'name'=>$request->input('name'),
                    'category_id'=>$request->input('category'),
                    'description'=>$request->input('description'),
                    'price'=>$request->input('price'),
                    'discount'=>$request->input('discount'),
                    'weight'=>$request->input('weight'),
             ]);

             if ($productupdate) {
                 return redirect('Showproduct/'. $request->input('id'))->with('message' , 'Product Updated successfully');
             }

             else{
                return back()->withInput();
             }

        }


    //}


       public function updateimage(Request $request){

         if ($request->hasFile('image') && $request->image->isValid()) {
                            $extention= $request->image->extension();
                            $filename= time()."_.".$extention;
                            $request->image->move(public_path('img'),$filename);
                        }

                        else{
                            $filename= 'no-image.png';
                        }

                        $product_img=image::where('id', $request->input('id'))->update([
                            'name'=>$filename,
                            
                        ]);

                        if ($product_img) {
                            return back()->with('message' , 'Image updated Successgully');
                        }

       }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }
}
