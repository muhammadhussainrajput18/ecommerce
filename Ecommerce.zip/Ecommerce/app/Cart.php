<?php
namespace App;

class Cart{

		private $contents;
		private $totalQty;
		private $totalprice;
		
		


		public function __construct($oldcart){

			if($oldcart){

				$this->contents =  $oldcart->contents;
				$this->totalQty =  $oldcart->totalQty;
				$this->totalprice =  $oldcart->totalprice;
				
			}
			}


			public function addProduct($product , $qty){
				$products = ['qty'=>0 , 'price'=>$product->price, 'product'=>$product];
				if ($this->contents) {
					if (array_key_exists($product->id, $this->contents)) {
						$products= $this->contents[$product->id];
					}
				}

				$products['qty']+=$qty;
				$products['price']=$product->price * $products['qty'];
				$this->contents[$product->id]=$products;

				$this->totalQty+=$qty;
				$this->totalprice += $product->price;
			
 
			}

			public function removeProduct($product){
        if ($this->contents) {
            if (array_key_exists($product->id, $this->contents)) {
                $rproduct=$this->contents[$product->id];
                $this->totalQty -=$rproduct['qty'];
                $this->totalprice -=$rproduct['price'];
                array_forget($this->contents, $product->id);

            }
        }


    }


    public function updateProduct($product , $qty){
    	if ($this->contents) {
    		if (array_key_exists($product->id, $this->contents)) {
    			$products= $this->contents[$product->id];
    		}
    	}

    	$this->totalQty -=$products['qty'];
    	$this->totalprice -=$products['price'];
    	$products['qty'] = $qty;
    	$products['price']= $product->price*$qty;
    	$this->totalprice += $products['price'];
    	$this->totalQty+=$qty;
    	$this->contents[$product->id]=$products;

    }


			public function getContents(){
				return $this->contents;

			}

			public function getTotalQty(){
				return $this->totalQty;
				
			}

			public function getTotalPrice(){
				return $this->totalprice;
				
			}

			public function getCountProduct(){
				return count($this->contents);
			}


}

?>